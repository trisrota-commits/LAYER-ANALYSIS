REPRODUCIBLE TABLE EVIDENCE — 2026-10-19, V2

Extract this ZIP locally. Do not upload its 677-file input archive contents individually to Overleaf.
The raw input archives remain compressed. The reproduction scripts read them directly.
Python 3.11+; numerical environment used here: NumPy 2.4.6, SciPy 1.17.1.

MAIN PAIRED TABLES:
python reproduce_main_paired_tables.py --archive article-tables-only-20261014-111938.tar.gz --output main_recomputed.log

LODO AND LOFO:
python reproduce_lodo_tables.py --archive holdout-reproduction-inputs-728444c5.zip --output lodo_recomputed.log --paired-reference experiment_logs/paired_holdout_tables.log --descriptive-reference experiment_logs/lodo_descriptive_table_evidence.log
python reproduce_lofo_tables.py --archive holdout-reproduction-inputs-728444c5.zip --output lofo_recomputed.log --reference experiment_logs/paired_holdout_tables.log
The original reports are under experiment_logs/ and are not intended to be overwritten.

See experiment_logs/TABLE_EVIDENCE_INDEX_v2.log for the table-by-table evidence map.
Checksums for each packaged file are in reproduction_packet_manifest.json.
Archived reports and old operator-transcribed calculations are labeled; fresh calculations include exact source hashes and settings.
The old TABLE_EVIDENCE_INDEX.log is excluded from this ZIP because its missing-input statements have been superseded. It remains preserved locally and in the original v1 ZIP.
This is numerical table evidence, not a promise of bitwise reproduction of GPU training.
