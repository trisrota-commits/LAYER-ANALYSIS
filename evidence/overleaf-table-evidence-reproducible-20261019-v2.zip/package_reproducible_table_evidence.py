from pathlib import Path
import hashlib,json,zipfile
BASE=Path(__file__).resolve().parent
OUT=BASE/'overleaf-logs-only-20261015-100424/experiment_logs'
ARCHIVES=[
 'holdout-reproduction-inputs-728444c5.zip',
 'article-tables-only-20261014-111938.tar.gz',
 'overleaf-experiment-logs-20261015-100424.zip',
 'article-timing-baselines-20261014-113919.tar.gz',
 'historical-22test-completed-20261015-094137.tar.gz',
 'article-dependence-source-20261014-150909.tar.gz',
 'lodo-four-datasets-verified-6bcc4c5c.zip',
 'lofo-seeds45-47-logs.zip',
]
SCRIPTS=['reproduce_main_paired_tables.py','reproduce_lodo_tables.py','reproduce_lofo_tables.py']
for n in ARCHIVES+SCRIPTS: assert (BASE/n).is_file(),n
for n in ['lodo_tables_reproduced.log','lofo_tables_reproduced.log']: assert (OUT/n).is_file(),n
old_packet=BASE/'overleaf-table-evidence-packet-20261019.zip'
with zipfile.ZipFile(old_packet) as z: table_map=json.loads(z.read('packet_manifest.json'))['tables']
replacements={
 'tab:lodo-taylor-zcp-off':('lodo_tables_reproduced.log','Fresh metrics from all seven folds\' archived raw prediction CSVs, six seeds, descriptive means and t intervals.'),
 'tab:lodo-taylor-record-bootstrap':('lodo_tables_reproduced.log','Fresh seven-fold architecture-grouped bootstrap from archived prediction CSVs/test prompts. See report for numerical comparison with previously printed results.'),
 'tab:lofo_best_accuracy':('lofo_tables_reproduced.log','Fresh original layer/no-layer six-seed descriptive results from archived prediction CSVs.'),
 'tab:lofo-taylor-zcp-off-comparison':('lofo_tables_reproduced.log','Fresh Taylor/OFF versus no-layer/ON six-seed descriptive results from archived prediction CSVs.'),
 'tab:lofo-taylor-grouped-bootstrap':('lofo_tables_reproduced.log','Fresh five-family architecture-grouped bootstrap. See report for numerical agreement/discrepancies with previously reported intervals.'),
}
for row in table_map:
 if row[0] in replacements:
  row[1],row[2]=replacements[row[0]]
for label,files,status in table_map:
 for n in files.split('; '): assert (OUT/n).is_file(),n
index='''TABLE EVIDENCE INDEX V2 — SUPERSEDES TABLE_EVIDENCE_INDEX.log
The missing holdout raw inputs have now been supplied and verified: holdout-reproduction-inputs-728444c5.zip, 677 hashed files.
Fresh LODO/LOFO numerical reproductions are included; old operator-transcript exports are retained only for historical provenance and comparison. Read the reproduced reports for agreement/discrepancy checks rather than assuming exact historical RNG equivalence.
The local ZIP contains raw numerical inputs and standalone main/LODO/LOFO numerical reproduction scripts. It does not include model weights or training datasets sufficient to rerun model fitting; no retraining is required for these statistical tables.
Overleaf: upload consolidated .log reports only. Keep the raw archives and reproduction scripts locally; do not unpack hundreds of input files into Overleaf.

Other evidence coverage is unchanged: archived experiment/report/data sources, initial matched comparison, timing/baselines, frozen dataset counts, initialization Taylor report and MIC source summaries. The MIC summary export does not itself rerun the estimator/permutation pipeline. No claim of fresh independent recomputation of every descriptive table or original model training is made.

TABLE MAP
'''
for label,files,status in table_map:index+=f'\n{label}\n  Evidence: {files}\n  Status: {status}\n'
index_path=OUT/'TABLE_EVIDENCE_INDEX_v2.log'
assert not index_path.exists(),'Refusing overwrite of v2 index'
index_path.write_text(index,encoding='utf-8',newline='\n')
assert index_path.read_text(encoding='utf-8')==index
readme='''REPRODUCIBLE TABLE EVIDENCE — 2026-10-19, V2

Extract this ZIP locally. Do not upload its 677-file input archive contents individually to Overleaf.
The raw input archives remain compressed. The reproduction scripts read them directly.
Python 3.11+; numerical environment used here: NumPy 2.4.6, SciPy 1.17.1.

MAIN PAIRED TABLES:
python reproduce_main_paired_tables.py --archive article-tables-only-20261014-111938.tar.gz --output main_recomputed.log

LODO AND LOFO:
python reproduce_lodo_tables.py --archive holdout-reproduction-inputs-728444c5.zip --output lodo_recomputed.log --paired-reference experiment_logs/paired_holdout_tables.log --descriptive-reference experiment_logs/lodo_descriptive_table_evidence.log
python reproduce_lofo_tables.py --archive holdout-reproduction-inputs-728444c5.zip --output lofo_recomputed.log --reference experiment_logs/paired_holdout_tables.log
The original reports are under experiment_logs/ and are not intended to be overwritten.

See experiment_logs/TABLE_EVIDENCE_INDEX_v2.log for the table-by-table evidence map.
Checksums for each packaged file are in reproduction_packet_manifest.json.
Archived reports and old operator-transcribed calculations are labeled; fresh calculations include exact source hashes and settings.
The old TABLE_EVIDENCE_INDEX.log is excluded from this ZIP because its missing-input statements have been superseded. It remains preserved locally and in the original v1 ZIP.
This is numerical table evidence, not a promise of bitwise reproduction of GPU training.
'''
packet=BASE/'overleaf-table-evidence-reproducible-20261019-v2.zip'
assert not packet.exists(),'Refusing overwrite of v2 ZIP'
manifest={}
with zipfile.ZipFile(packet,'x',zipfile.ZIP_DEFLATED) as z:
 def add(p,name):
  data=p.read_bytes();z.writestr(name,data);manifest[name]={'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data)}
 for p in sorted(OUT.glob('*.log')):
  if p.name!='TABLE_EVIDENCE_INDEX.log':add(p,'experiment_logs/'+p.name)
 for name in ARCHIVES+SCRIPTS:add(BASE/name,name)
 for name in ['lodo_tables_reproduced.json','lofo_tables_reproduced.json']:
  p=BASE/name
  if p.exists():add(p,name)
 add(Path(__file__),Path(__file__).name)
 z.writestr('README.txt',readme)
 z.writestr('reproduction_packet_manifest.json',json.dumps({'tables':table_map,'files':manifest},indent=2))
with zipfile.ZipFile(packet) as z:
 assert z.testzip() is None
 for name,info in manifest.items():assert hashlib.sha256(z.read(name)).hexdigest()==info['sha256']
print('PACKET',packet)
print('SHA256',hashlib.sha256(packet.read_bytes()).hexdigest())
print('TABLES',len(table_map),'FILES',len(manifest))
print('ZIP integrity and all packaged source/report/script hashes: PASS')
