# Verified NB201 Qwen Taylor/no-layer comparison

## Conclusion

The Taylor MAE gain reproduces on both tested NAS-Bench-201 datasets under the frozen adapted protocols. These are actual Qwen predictions, not the preceding classical fast-tier results. All six matched predictor seeds favor Taylor within each dataset on the target >=20% primary population.

## Execution and integrity

- Source archive: `evidence/nb201-qwen-predictions-v1.tar.gz`.
- SHA256: `024275fe9fddaadf5d36207a1a9c4a1ed4626418eed4a7b4a20a49f7587ecb7e`, matching the user's cluster checksum.
- Extracted into the separate `evidence/nb201-qwen-results-v1/`; 272 regular-file members verified against extracted bytes. Existing archive/prepared bundle unchanged.
- User-provided cluster output: all24 Jobs1/1, PodsCompleted, zero restarts. Per-run receipts:7epochs,275valid predictions,0parse failures.
- Independently verified exact test IDs/order against frozen cohorts, raw/exported prediction equality, prediction/registry/contract hashes, matched training settings and effective/adapter seeds42–47.
- Each fit used825 train+validation records, seven epochs, same seed42-selected hyperparameters, batch4/accumulation8, lr.0001, weight decay.013, max-grad-norm.5, warmup3steps. No test selection or retraining performed here.
- Effective training cap1024; all prompts fit without truncation. Same recorded packages for all24 runs. GPUs:6runs RTX4090,18runs RTX3090. Runtime package versions: Torch2.7.1+cu126, Transformers5.2.0, TRL0.24.0, Unsloth2026.3.4, Unsloth-zoo2026.3.2, datasets3.6.0, PEFT0.21.2.
- Receipts report24 distinct adapter hashes; checkpoint weights were not downloaded/rehashed locally.

## Primary endpoint

MAE on target >=20% records, averaged over six separately fitted predictor metrics; positive difference is no-layer minus Taylor. Values are accuracy percentage points. CIs below are paired-record t intervals, not bootstrap intervals.

| Dataset | n | No-layer MAE | Taylor MAE | Improvement | Relative reduction | 95% record t CI | Record Holm2 p | Seed Holm2 p |
|---|---:|---:|---:|---:|---:|---|---:|---:|
| CIFAR-10-valid | 273 | 2.916844 | 2.225244 | 0.691600 | 23.71% | [0.417737,0.965462] | 2.352792e-6 | 2.679528e-4 |
| CIFAR-100 | 272 | 3.736262 | 2.743658 | 0.992604 | 26.57% | [0.633220,1.351988] | 2.411360e-7 | 1.475268e-4 |

Holm2 is the declared two-test primary family within each dataset. An additional conservative Holm correction across all four primary tests also retains significance; adjusted values are saved in `verification.json`.

## All 275 test records per dataset

Means of per-seed metrics, NOT prediction ensembles. These five-metric summaries are descriptive; inferential superiority was assessed for MAE, not separately established for every metric.

| Dataset | Arm | MAE | RMSE | Pearson | Spearman | R2 |
|---|---|---:|---:|---:|---:|---:|
| CIFAR-10-valid | No layer | 2.895727 | 4.949945 | 0.835534 | 0.494613 | 0.670718 |
| CIFAR-10-valid | Taylor | 2.209267 | 3.905624 | 0.899673 | 0.707213 | 0.794273 |
| CIFAR-100 | No layer | 3.780309 | 5.943643 | 0.783911 | 0.584076 | 0.590547 |
| CIFAR-100 | Taylor | 2.784261 | 4.436380 | 0.882843 | 0.805912 | 0.771904 |

## Robustness checks on the primary population

All randomized checks use10000draws; seed0, except class-stratified AUROC resampling uses seed1 as explicitly coded.

| Check | CIFAR-10-valid | CIFAR-100 |
|---|---|---|
| Record bootstrap 95% CI | [0.424617,0.979189] | [0.637057,1.346281] |
| Record+seed bootstrap 95% CI | [0.377288,1.016005] | [0.585642,1.399280] |
| Operation-multiset family bootstrap 95% CI | [0.409435,1.039743] | [0.628755,1.427357] |
| Wilcoxon record p | 2.725876e-7 | 2.473804e-10 |
| Crossed random-intercept model p | 3.446096e-6 | 7.116854e-7 |
| Cell sign-flip Monte Carlo p | 9.999000e-5 | 9.999000e-5 |

Both mixed models converged with L-BFGS and no recorded numerical warnings; no fallback was used. This is distinct from the earlier LEMUR validation, whose mixed-model diagnostics remained invalid. The cell-wise sign-flip test assumes exchangeability despite shared records/seeds and is only a supporting sensitivity calculation; the primary and family-cluster results do not rely on it. Robustness p-values are unadjusted supporting tests.

Collapse AUROC is identical between arms:1.0 on CIFAR10,0.998775 on CIFAR100. There are only2 and3 collapsed records respectively, so do not infer reliable near-certain stopping or a Taylor-specific collapse-detection gain.

## Protocol boundaries

- CIFAR10: benchmark seed-averaged early accuracies; target is peak of available-seed mean validation curve.
- CIFAR100: locally measured early accuracies; target is fixed-seed777/888 mean epoch200 validation accuracy, not peak accuracy.
- Assistant targets are rounded to2decimals; raw benchmark targets remain in registries. Prior classical targets retain full precision.
- Frozen operation-multiset-grouped772/53/275 split per dataset; this is not evidence over arbitrary new splits, benchmarks or candidate-training seeds.
- Uses our independent `nb201_v1/primary_endpoint.py`, derived from documented manuscript methods. It is not the missing supervisor source verbatim. All numerical/method choices are recorded in each report.
- The result supports added predictive value from Taylor. It does not establish that Qwen beats classical predictors or that Taylor universally replaces all zero-cost proxies.

## Independent verification

`verification.json` records independent calculations from actual standardized prediction CSVs:
1. All24 per-run five-metric results matched the original evaluator reports.
2. Both datasets' record/seed paired t-test p-values and confidence intervals reproduced using scipy.ttest_rel.
3. All10000 record, two-way and cell-flip resample statistics reproduced with a separate calculation.
4. Saved bootstrap percentile endpoints and reported p-values reproduced.
5. Report/source hashes matched; additional global Holm4 calculation saved.

Outputs per dataset: `inputs/{panel.csv,registry.json,source_hashes.json}` and `analysis/{results.json,resamples.npz,paired_record_errors.csv,complete.json}` under this directory. Original predictions and checkpoints unchanged.

## Provisional article paragraph (not inserted)

In a partial replication on NAS-Bench-201, adding early-training Taylor measurements to the matched three-accuracy, ZCP-disabled Qwen predictor reduced held-out non-collapsed MAE from 2.9168 to 2.2252 percentage points on CIFAR-10-valid and from 3.7363 to 2.7437 on CIFAR-100, relative reductions of 23.71% and 26.57%. The improvement occurred in every matched predictor seed and remained significant for both record-paired and seed-paired tests after Holm correction. Operation-multiset-cluster bootstrap intervals also excluded zero on both datasets. These results extend the observed predictive benefit of Taylor beyond LEMUR under the tested protocols; CIFAR-100 uses a final-epoch target and locally measured early accuracies, whereas CIFAR-10 uses benchmark early accuracies and a peak-curve target.
