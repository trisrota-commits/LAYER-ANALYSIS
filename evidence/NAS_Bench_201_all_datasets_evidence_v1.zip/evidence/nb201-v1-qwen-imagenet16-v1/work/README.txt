Dedicated writable working directory; required before submission.
