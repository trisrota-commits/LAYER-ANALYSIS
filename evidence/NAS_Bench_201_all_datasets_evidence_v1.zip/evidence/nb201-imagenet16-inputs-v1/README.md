# ImageNet16-120 NB201 acquisition

New experiment: nb201-v1-imagenet16-full. No existing CIFAR experiment is modified.

## Protocol
- Same frozen 1100 architecture indices and 772/53/275 operation-multiset-group split.
- Candidate initialization seed777; three training epochs from the official 200-epoch schedule; C16/N5, 120 classes, 16x16 images.
- Full151700 training images. Early validation uses the official3000-image x-valid subset of6000; x-test is not evaluated.
- Original Taylor extraction/state-protection/training functions reused from the verified CIFAR acquisition source; fixed augmented training batch256, extraction seed20261025.
- Target: mean epoch200 x-valid over fixed benchmark seeds777/888. Local early accuracies and Taylor share a candidate run. Do not use a peak-accuracy prompt for this dataset.
- Official benchmark metadata was checked for all1100 architectures. No complete early x-valid curves exist in this archive for those fixed seeds. There are258 test targets >=20% and17 below20%.

## Stages
This package prepares FEATURE ACQUISITION, not Qwen fitting. Pilot is the first three frozen architectures (3,32,41). Their successful results count in the final cohort; four later shards cover only the remaining1097. All five internal shard reports are required for collection. No automatic retry, overwrite, data deletion or cohort replacement.

After collection, the intended predictor experiments are the same matched ridge/HistGB comparisons and Taylor/no-layer Qwen seeds42-47, followed by separate-dataset statistical analysis. Those ImageNet predictor inputs and Jobs are not yet generated or submitted.

## Cluster commands (after verified unpacking)

```bash
python3 -B /shared/ssd/home/b-t-bose/lmur/nb201-imagenet16-inputs-v1/imagenet16.py prepare
python3 -B /shared/ssd/home/b-t-bose/lmur/nb201-v1-imagenet16-full/runner.py check
python3 -B /shared/ssd/home/b-t-bose/lmur/nb201-v1-imagenet16-full/runner.py pilot
```

Default dataset directory is `/shared/ssd/home/b-t-bose/lmur/nn-dataset/data/ImageNet16`. Preparation checks all11 official batch MD5 values using only the standard library; it does not download data. To use a different verified shared directory, pass `--data /absolute/shared/path` to prepare. It refuses worker-local `/shared/local` data paths because readiness is checked from the login host.

Preparation reuses the immutable source snapshot under `nas201-taylor-pilot-v1`: its runner, LayerAnalysis.py, pinned AutoDL source and Job template. Hash guards stop on source drift. The supplied cifar100.py is a frozen READ-ONLY source dependency for generating the new collection copy, not a request to rerun CIFAR.

Jobs use pinned image `docker.io/abrainone/ai-linux@sha256:af6bc18dcfcc9cdf73deef2ef916d0d8408318cddceedd0208e6b88208e05e14`, project/data read-only mounts, and a separate writable output root. No node restriction is inherited; dataset data comes from an explicit shared mount. Training runs inside GPU pods, not in the login node's CPU loader environment.

```bash
kubectl -n b-t-bose get jobs,pods -l experiment-batch=nb201-v1-imagenet16-full -o wide
kubectl -n b-t-bose logs job/nb201-v1-imagenet16-full-pilot -c collector --tail=80
python3 -B /shared/ssd/home/b-t-bose/lmur/nb201-v1-imagenet16-full/runner.py show
```

Only after the pilot Job and all its candidate artifacts pass:

```bash
python3 -B /shared/ssd/home/b-t-bose/lmur/nb201-v1-imagenet16-full/runner.py full
```

After all shards succeed:

```bash
python3 -B /shared/ssd/home/b-t-bose/lmur/nb201-v1-imagenet16-full/runner.py collect
```

This exclusively creates snapshot.jsonl and collection_complete.json. Preserve partial outputs and failure receipts if anything fails. Do not rerun prepare/pilot/full blindly.

## Verification boundaries
Targets are real released benchmark values. Local tests cover actual target parsing, complete frozen cohort/split coverage, unchanged measurement/training function ASTs, ImageNet transforms/classes/counts, real fixture checksums, exact record validation, generated Jobs/mounts, pilot-before-full gating and exclusive full collection. GPU candidate training and Kubernetes API calls are mocked in local tests; generated synthetic fixture data are disposable and not experiment results. Real cluster dataset readiness, server dry-run and GPU pilot success remain unverified until user execution.
