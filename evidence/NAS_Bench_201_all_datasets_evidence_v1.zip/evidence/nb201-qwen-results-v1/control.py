import csv
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
PILOT = 'cifar10-taylor-s42'

def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

def host(p):
    return ROOT / Path(p).relative_to('/a/mm')

def verify():
    manifest = json.loads((HERE / 'manifest.json').read_text())
    for name, digest in manifest.items():
        assert sha(HERE / name) == digest, ('Bundle drift', name)
    contract = json.loads((HERE / 'contract.json').read_text())
    for name, digest in contract['source_sha256'].items():
        assert sha(host(name)) == digest, ('Source/input drift', name)
    for run in contract['runs'].values():
        for name, digest in run['selection_sha256'].items():
            assert sha(host(run['selected']) / name) == digest, ('Saved settings drift', name)
    base = host(contract['base'])
    index = json.loads((base / 'model.safetensors.index.json').read_text())
    for name in ('config.json', 'tokenizer.json', *set(index['weight_map'].values())):
        assert (base / name).is_file() and (base / name).stat().st_size > 0, name
    print('PREFLIGHT_PASS; free GiB:', round(shutil.disk_usage(HERE).free / 2**30, 2), flush=True)
    return contract

def completed(key):
    out = HERE / 'results' / key
    done = json.loads((out / 'test_complete.json').read_text())
    prediction = json.loads((out / 'prediction_contract.json').read_text())
    runtime = json.loads((out / 'runtime_preflight.json').read_text())
    assert done['run'] == prediction['run'] == runtime['run'] == key
    assert done['n_samples'] == done['n_valid'] == prediction['n'] == prediction['finite_accuracy_predictions'] == 275
    assert done['parse_failures'] == runtime['over_cap_records'] == 0
    assert sha(out / 'per_record_predictions.csv') == prediction['prediction_sha256']
    return done

def main():
    action = sys.argv[1]
    assert action in ('check', 'pilot', 'remaining', 'show')
    contract = verify()
    if action == 'check':
        return
    if action == 'show':
        for key in contract['runs']:
            out = HERE / 'results' / key
            if (out / 'test_complete.json').exists():
                print(key, json.loads((out / 'test_complete.json').read_text()))
            else:
                print(key, 'artifacts present' if out.exists() else 'not started')
        return
    if action == 'remaining':
        completed(PILOT)
        job = json.loads(subprocess.check_output(['kubectl', '-n', 'b-t-bose', 'get', 'job', HERE.name + '-' + PILOT, '-o', 'json'], text=True))
        assert job.get('status', {}).get('succeeded') == 1, 'Pilot Job not completed'
    keys = [PILOT] if action == 'pilot' else [k for k in contract['runs'] if k != PILOT]
    for key in keys:
        assert not (HERE / 'results' / key).exists(), ('Existing results preserved', key)
        existing = subprocess.check_output(['kubectl', '-n', 'b-t-bose', 'get', 'job', HERE.name + '-' + key, '--ignore-not-found', '-o', 'name'], text=True)
        assert not existing.strip(), ('Job already exists; do not resubmit', key)
        subprocess.run(['kubectl', '-n', 'b-t-bose', 'create', '--dry-run=server', '-f', str(HERE / 'jobs' / (key + '.json'))], check=True)
    for key in keys:
        subprocess.run(['kubectl', '-n', 'b-t-bose', 'create', '-f', str(HERE / 'jobs' / (key + '.json'))], check=True)

if __name__ == '__main__':
    main()
