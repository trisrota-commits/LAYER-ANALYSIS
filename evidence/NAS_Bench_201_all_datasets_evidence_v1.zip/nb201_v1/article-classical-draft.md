# Provisional NB201 classical comparison — not the Qwen replication

## Suggested article text

To assess whether the predictive utility of early-training Taylor measurements extends beyond LEMUR, we conducted a matched classical-predictor comparison on NAS-Bench-201. For each of CIFAR-10-valid and CIFAR-100, the frozen cohort comprised 1,100 architectures, partitioned into 772 training, 53 validation, and 275 held-out architectures with disjoint operation-multiset groups. Following the supplied fast-tier workflow, ridge regression and histogram gradient boosting were fitted on the combined training and validation partitions. Both arms used the three early accuracy observations and their consecutive differences; the Taylor arm additionally received the three corresponding layer-averaged Taylor measurements. No test-based model selection was performed.

Adding Taylor reduced gradient-boosting test MAE from 2.7011 to 1.8504 percentage points on CIFAR-10-valid and from 3.3683 to 2.5167 on CIFAR-100, corresponding to reductions of 31.49% and 25.28%. The paired MAE improvements were 0.8507 and 0.8517 percentage points; their 95% operation-multiset-cluster bootstrap intervals were [0.5581, 1.1874] and [0.4091, 1.3659], respectively. Both improvements remained positive under the stated eight-comparison Bonferroni-adjusted percentile intervals and when evaluation was restricted to targets of at least 20%. Ridge also improved on CIFAR-100, while its CIFAR-10 improvement was inconclusive. These results support the usefulness of Taylor features beyond the original corpus for classical prediction, without establishing replication of the fine-tuned LLM result.

## All-held-out results

| Dataset | Predictor | MAE without Taylor | MAE with Taylor | Improvement | 95% family-cluster CI | Bonferroni-adjusted family-cluster CI |
|---|---|---:|---:|---:|---|---|
| CIFAR-10-valid | Ridge | 6.6361 | 6.5022 | 0.1339 | [-0.0823, 0.3877] | [-0.1627, 0.5025] |
| CIFAR-10-valid | HistGradientBoosting | 2.7011 | 1.8504 | 0.8507 | [0.5581, 1.1874] | [0.4312, 1.3418] |
| CIFAR-100 | Ridge | 6.5728 | 6.0197 | 0.5530 | [0.2284, 0.8864] | [0.0849, 1.0422] |
| CIFAR-100 | HistGradientBoosting | 3.3683 | 2.5167 | 0.8517 | [0.4091, 1.3659] | [0.2110, 1.6047] |

## Method details that must accompany the result

- CIFAR-10 inputs use benchmark seed-averaged early accuracies; its target is the peak of the available-seed mean validation curve. CIFAR-100 inputs use local early accuracies; its target is mean epoch-200 validation accuracy over benchmark seeds 777 and 888. Do not describe the latter as peak accuracy.
- Models/settings are the unchanged supplied `original/panel.py` fast tier: median imputation is NOT used here; its SimpleImputer default is mean. Ridge uses standardization and RidgeCV over 13 logarithmically spaced alphas. HistGradientBoosting uses the installed sklearn defaults. Both fit on 825 train+validation records, as in that script. Ridge internal cross-validation is not a new family-disjoint validation procedure; preprocessing is fitted on the combined fitting set before that internal selection. The held-out test families remain excluded.
- Six seed-labelled fits (42–47) were executed for each arm, but predictions were identical across seeds in each model/dataset/arm. These are not six independent demonstrations of robustness. Report record/family uncertainty, not artificial seed variability.
- 10,000 percentile bootstrap draws, NumPy seed 0; differences are no-Taylor minus Taylor MAE, so positive favors Taylor. Absolute errors are averaged across fitted seeds before paired resampling, not predictions ensembled. Cluster resampling samples operation-multiset groups with replacement and retains all member records, estimating record-weighted MAE differences.
- Eight comparison endpoints: two datasets x two models x two populations (all test targets; target >=20%). Bonferroni-adjusted percentile intervals are reported separately for IID-record and family-cluster resampling. This is an interim analysis, NOT the unavailable supervisor `primary_endpoint.py` Holm/robustness analysis.
- The >=20% subset contains 273 CIFAR-10 and 272 CIFAR-100 records. It follows the attachment's numerical threshold; it is not a universal, dataset-calibrated collapse definition.
- Results are conditional on this frozen split and collected measurements, not uncertainty over new candidate training seeds or split resampling.

## Artifacts and outstanding work

Evidence: `evidence/nb201-classical-matched-v1/` contains the frozen contract, per-record predictions, per-seed five-metric summaries, panels, test registries, saved bootstrap draws, results and completion hashes. Runner: `nb201_v1/evaluate.py`; focused tests: `nb201_v1/test_evaluate.py`. Source snapshots and original attached scripts were unchanged.

Still pending: matched Qwen fits/evaluation, the supervisor's exact primary-endpoint analysis, and integration/compilation in the authoritative manuscript. This draft is not inserted into the paper.
