"""Move only unstarted NB201 shards to unrestricted workers with shared-data checks.
Original prepared manifests/runner hashes and all existing outputs are preserved.
"""
import argparse,copy,hashlib,json,re,subprocess,sys
from pathlib import Path

NS='b-t-bose'
ARCHIVE='nb201-worker-placement-v1'
SCOPE=[('nb201-v1-cifar10-full',3)]+[('nb201-v1-cifar100-full',k) for k in range(4)]

def require(ok,msg):
    if not ok:raise RuntimeError(msg)

def js(p):return json.loads(Path(p).read_text())
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def put(p,x):
    p=Path(p);p.parent.mkdir(parents=True,exist_ok=True)
    with p.open('x') as f:json.dump(x,f,indent=2)

def kube(*args,check=True):
    r=subprocess.run(['kubectl','-n',NS,*args],capture_output=True,text=True)
    if check:require(r.returncode==0,r.stderr or r.stdout)
    return r

def get(kind,name):
    text=kube('get',kind,name,'--ignore-not-found','-o','json').stdout.strip()
    return json.loads(text) if text else None

def owned_pods(job):
    uid=job['metadata']['uid']
    items=json.loads(kube('get','pods','-l',f'batch.kubernetes.io/controller-uid={uid}','-o','json').stdout)['items']
    return [p for p in items if any(r.get('uid')==uid and r.get('kind')=='Job' for r in p['metadata'].get('ownerReferences',[]))]

def unstarted(pod):
    if pod.get('status',{}).get('phase')!='Pending' or pod['spec'].get('nodeName'):return False
    if pod['metadata'].get('deletionTimestamp'):return False
    for status in pod.get('status',{}).get('containerStatuses',[])+pod.get('status',{}).get('initContainerStatuses',[]):
        if status.get('restartCount',0) or 'running' in status.get('state',{}) or 'terminated' in status.get('state',{}):return False
    return True

def untouched_outputs(root,batch,shard):
    out=root/batch/'results'
    require(not (out/'shards'/f's{shard}').exists(),f'Shard state exists: {batch}/{shard}; preserving')
    ids=js(root/batch/'manifest.json')['shards'][shard]
    present=[i for i in ids if (out/'candidates'/f'{i:05d}').exists()]
    require(not present,f'Candidate outputs exist for {batch}/{shard}: {present[:5]}')

def subset(expected,actual):
    if isinstance(expected,dict):return isinstance(actual,dict) and all(k in actual and subset(v,actual[k]) for k,v in expected.items())
    if isinstance(expected,list):return isinstance(actual,list) and len(expected)==len(actual) and all(subset(x,y) for x,y in zip(expected,actual))
    return expected==actual

def image_digest():
    selector='experiment-batch in (nb201-v1-cifar10-full,nb201-v1-cifar100-full)'
    pods=json.loads(kube('get','pods','-l',selector,'--field-selector=status.phase=Running','-o','json').stdout)['items']
    for p in pods:
        for status in p.get('status',{}).get('containerStatuses',[]):
            if status.get('name')!='collector' or 'running' not in status.get('state',{}):continue
            value=status.get('imageID','').split('://')[-1]
            if re.fullmatch(r'.+@sha256:[0-9a-f]{64}',value):return value,p['metadata']['name']
            if re.fullmatch(r'sha256:[0-9a-f]{64}',value):
                image=next(c['image'] for c in p['spec']['containers'] if c['name']=='collector')
                repository=image.split('@')[0].rsplit(':',1)[0]
                require(repository,'Cannot resolve image repository')
                return repository+'@'+value,p['metadata']['name']
    raise RuntimeError('No running acquisition container exposes a usable image digest; no Jobs changed')

def replacement(saved,batch,shard,image):
    job=copy.deepcopy(saved);old=f'{batch}-s{shard}';name=old+'-shared-v1'
    labels={**job['metadata'].get('labels',{}),'placement-override':'nb201-shared-v1','source-job':old}
    job['metadata']={'name':name,'namespace':NS,'labels':labels}
    job.pop('status',None);job['spec']['suspend']=False
    job['spec']['template']['metadata']={'labels':labels.copy()}
    pod=job['spec']['template']['spec']
    require(pod.get('nodeSelector')=={'kubernetes.io/hostname':'w2-mi'},'Unexpected saved selector')
    require(not pod.get('nodeName') and not pod.get('affinity'),'Unexpected placement constraint')
    require(not pod.get('initContainers'),'Unexpected existing init containers')
    del pod['nodeSelector']
    volumes={v['name']:v for v in pod['volumes']}
    require(volumes['data']['hostPath']['path']=='/shared/local/data/a-group-automl/data','Unexpected original data mount')
    volumes['data']['hostPath']={'path':'/shared/hdd/data','type':'Directory'}
    require(len(pod['containers'])==1,'Unexpected main-container count')
    main=pod['containers'][0];main['image']=image
    mounts={v['name']:v for v in main['volumeMounts']}
    require(mounts['data']['mountPath']=='/a/data' and mounts['data'].get('readOnly') is True,'Unexpected data access')
    require(mounts['project']['mountPath']=='/a/project' and mounts['project'].get('readOnly') is True,'Unexpected source access')
    dataset='CIFAR100' if 'cifar100' in batch else 'CIFAR10'
    classes=100 if dataset=='CIFAR100' else 10
    code=f'''from pathlib import Path
import json, torch, torchvision, numpy
from torchvision.datasets import {dataset}
assert torch.__version__ == '2.7.1+cu126', torch.__version__
assert torchvision.__version__ == '0.22.1', torchvision.__version__
assert numpy.__version__ == '2.2.5', numpy.__version__
assert Path('/a/project/{batch}/runner.py').is_file()
for train, expected in [(True,50000),(False,10000)]:
    data={dataset}('/a/data', train=train, download=False)
    assert len(data)==expected and len(data.classes)=={classes}
    for index in (0,len(data)-1):
        image,label=data[index]
        assert image.size==(32,32) and 0<=label<{classes}
print('SHARED_DATA_PREFLIGHT_PASS', '{dataset}', 'official torchvision integrity checks and endpoint decoding passed', flush=True)
'''
    pod['initContainers']=[dict(name='verify-shared-data',image=image,imagePullPolicy=main.get('imagePullPolicy','IfNotPresent'),
        command=['python3','-B','-c'],args=[code],
        env=[{'name':'PYTHONDONTWRITEBYTECODE','value':'1'},{'name':'PYTHONPATH','value':''},{'name':'OMP_NUM_THREADS','value':'1'}],
        resources={'requests':{'cpu':'1','memory':'2Gi'},'limits':{'cpu':'2','memory':'4Gi'}},
        volumeMounts=[copy.deepcopy(mounts['project']),copy.deepcopy(mounts['data'])])]
    return job

def plan(root):
    archive=root/ARCHIVE;require(not archive.exists(),'Placement archive already exists; do not regenerate')
    image,reference=image_digest();items=[]
    for batch,shard in SCOPE:
        name=f'{batch}-s{shard}';job=get('job',name)
        if not job:print('SKIP missing original:',name);continue
        pods=owned_pods(job)
        if len(pods)!=1 or not unstarted(pods[0]) or job['spec'].get('suspend',False):
            print('SKIP; not a single unstarted pending Pod:',name);continue
        require(not job.get('status',{}).get('succeeded',0) and not job.get('status',{}).get('failed',0),'Original has completed/failed history')
        untouched_outputs(root,batch,shard)
        path=root/batch/'jobs'/f's{shard}.json';expected=js(root/batch/'contract.json')['sha256'][f'jobs/s{shard}.json']
        require(sha(path)==expected,'Stored manifest drift: '+str(path))
        saved=js(path)
        require(subset(saved['spec']['template']['spec'],job['spec']['template']['spec']),'Live Pod template differs from saved one')
        new=replacement(saved,batch,shard,image)
        require(get('job',new['metadata']['name']) is None,'Replacement Job already exists')
        items.append(dict(batch=batch,shard=shard,old_name=name,old_uid=job['metadata']['uid'],pod_name=pods[0]['metadata']['name'],pod_uid=pods[0]['metadata']['uid'],
            source_manifest_sha256=expected,old_job=job,old_pod=pods[0],replacement=new))
    require(items,'No eligible pending Jobs; nothing changed')
    archive.mkdir(mode=0o700)
    entries=[]
    for item in items:
        folder=archive/item['old_name']
        for name,key in [('job-before.json','old_job'),('pod-before.json','old_pod'),('replacement.json','replacement')]:put(folder/name,item[key])
        p=folder/'replacement.json'
        kube('create','--dry-run=server','-f',str(p))
        entry={k:v for k,v in item.items() if k not in ['old_job','old_pod','replacement']}
        entry.update(new_name=item['replacement']['metadata']['name'],replacement_sha256=sha(p))
        entries.append(entry)
    put(archive/'plan.json',dict(status='planned',reference_image=image,reference_pod=reference,entries=entries,
        safety='Apply rechecks pending state/output absence and uses Job UID/resourceVersion tests. Cross-resource Pod/Job checks are not atomic. Outputs appearing during suspension block replacement.'))
    print('PLAN READY:',archive,'; replacements:',len(entries),'; NO Jobs changed.')
    for e in entries:print(e['old_name'],'->',e['new_name'])

def apply(root):
    archive=root/ARCHIVE;plan=js(archive/'plan.json');outcomes=[]
    for entry in plan['entries']:
        batch,k=entry['batch'],entry['shard'];folder=archive/entry['old_name'];path=folder/'replacement.json'
        try:
            require(sha(path)==entry['replacement_sha256'],'Replacement changed')
            require(sha(root/batch/'jobs'/f's{k}.json')==entry['source_manifest_sha256'],'Original manifest changed')
            expected=js(path)
            existing=get('job',entry['new_name'])
            if existing:
                require(subset(expected['spec']['template']['spec'],existing['spec']['template']['spec']),'Existing replacement differs')
                print('PRESERVED existing replacement:',entry['new_name']);continue
            old=get('job',entry['old_name']);require(old is not None and old['metadata']['uid']==entry['old_uid'],'Original Job identity changed')
            untouched_outputs(root,batch,k)
            if old['spec'].get('suspend',False):
                require((folder/'suspended.json').exists(),'Original already suspended without this script receipt; inspect')
            else:
                pods=owned_pods(old)
                if len(pods)!=1 or pods[0]['metadata']['uid']!=entry['pod_uid'] or not unstarted(pods[0]):
                    print('SKIP; original was scheduled or changed:',entry['old_name']);continue
                # Repeat validation before the only workload mutation.
                kube('create','--dry-run=server','-f',str(path))
                current=get('pod',entry['pod_name']);require(current is not None and current['metadata']['uid']==entry['pod_uid'] and unstarted(current),'Pod started/changed; stop')
                untouched_outputs(root,batch,k)
                patch=[{'op':'test','path':'/metadata/uid','value':entry['old_uid']},
                       {'op':'test','path':'/metadata/resourceVersion','value':old['metadata']['resourceVersion']},
                       {'op':'add','path':'/spec/suspend','value':True}]
                kube('patch','job',entry['old_name'],'--type=json','-p',json.dumps(patch))
                put(folder/'suspended.json',dict(job_uid=entry['old_uid'],pod_uid=entry['pod_uid']))
            # Suspension stops the old controller from launching another writer.
            pod=get('pod',entry['pod_name'])
            if pod:
                require(pod['metadata']['uid']==entry['pod_uid'],'Pod name reused')
                kube('wait','--for=delete','pod/'+entry['pod_name'],'--timeout=120s',check=False)
            old=get('job',entry['old_name'])
            require(old is not None and old['metadata']['uid']==entry['old_uid'] and old['spec'].get('suspend') is True,'Suspension not established')
            require(not owned_pods(old),'Original Pod still exists; no replacement created')
            untouched_outputs(root,batch,k)
            result=kube('create','-f',str(path));print(result.stdout.strip(),flush=True)
            fresh=get('job',entry['new_name']);require(fresh is not None,'Replacement creation not confirmed')
            put(folder/'created.json',dict(new_job=entry['new_name'],new_uid=fresh['metadata']['uid']))
            outcomes.append(dict(job=entry['new_name'],status='created'))
        except Exception as e:
            outcomes.append(dict(job=entry['new_name'],status='blocked',error=str(e)))
            print('STOP FOR THIS SHARD:',entry['old_name'],str(e),flush=True)
    print(json.dumps(outcomes,indent=2))
    require(not any(r['status']=='blocked' for r in outcomes),'Some replacements blocked; preserve state and inspect above')
    print('PLACEMENT APPLY COMPLETE. New Jobs still require successful init checks and scheduling; running originals were not selected.')

def main():
    p=argparse.ArgumentParser();p.add_argument('action',choices=['plan','apply']);p.add_argument('--root',type=Path,default=Path('/shared/ssd/home/b-t-bose/lmur'))
    a=p.parse_args();{'plan':plan,'apply':apply}[a.action](a.root)

if __name__=='__main__':main()
