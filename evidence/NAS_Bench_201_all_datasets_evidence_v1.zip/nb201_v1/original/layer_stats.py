#!/usr/bin/env python3
"""
Layer-statistic extractor for the NAS-Bench-201 replication.

Implements the seven features of Supplement Sec. S-I-B (Layer-Statistic
Definitions) so that the values produced here are comparable, feature by
feature, with the LEMUR snapshot:

  ww_alpha     fitted power-law exponent of the weight ESD   (spectral)
  grad_norm    || vec(grad_W) ||_2                           (gradient)
  dead_frac    fraction of |A| < 1e-6                        (activation)
  taylor_imp   mean | A * dL/dA |                             (act.-gradient)
  cka_redund   mean linear CKA with every other layer        (representation)
  rank_ratio   entropy effective rank / min(m, n)            (spectral)
  sensitivity  relative loss increase when W_l, b_l := 0     (perturbation)

Analyzed modules are Conv2d, ConvTranspose2d and Linear, as in LEMUR.
Data-dependent statistics use one analysis batch; sensitivity uses up to
five, matching the LEMUR runner.

Run-level reduction: arithmetic mean over layers with a finite value, which
is what the predictor prompt's LAYER_STATS_MEAN_BY_EPOCH table contains.
"""
from __future__ import annotations

import math
import numpy as np
import torch
import torch.nn as nn

STATS = ["ww_alpha", "grad_norm", "dead_frac", "taylor_imp",
         "cka_redund", "rank_ratio", "sensitivity"]

TARGET_TYPES = (nn.Conv2d, nn.ConvTranspose2d, nn.Linear)
DEAD_EPS = 1e-6


# --------------------------------------------------------------------------
# spectral features (weights only, no data needed)
# --------------------------------------------------------------------------
def _as_matrix(w: torch.Tensor) -> np.ndarray:
    """Reshape a weight tensor to m x n with m = output dimension."""
    w = w.detach().float().cpu()
    return w.reshape(w.shape[0], -1).numpy()


def rank_ratio(w: torch.Tensor) -> float:
    """Entropy effective rank divided by min(m, n)  (Supp. eq. for q_l)."""
    M = _as_matrix(w)
    try:
        s = np.linalg.svd(M, compute_uv=False)
    except np.linalg.LinAlgError:
        return float("nan")
    s = s[s > 0]
    if s.size == 0:
        return 0.0
    p = s / s.sum()
    r_eff = float(np.exp(-(p * np.log(p)).sum()))
    return r_eff / min(M.shape)


def ww_alpha(w: torch.Tensor) -> float:
    """
    Power-law tail exponent of the weight ESD.

    LEMUR calls WeightWatcher.analyze(); we reproduce it with the same
    underlying estimator (powerlaw's MLE over eigenvalues of W^T W, which is
    what WeightWatcher's PL fit uses).  If neither weightwatcher nor powerlaw
    is installed the value is NaN -- harmless for the Taylor replication,
    which never reads this column, but then do not compare ww_alpha across
    corpora.
    """
    M = _as_matrix(w)
    if min(M.shape) < 2:
        return float("nan")
    try:
        sv = np.linalg.svd(M, compute_uv=False)
    except np.linalg.LinAlgError:
        return float("nan")
    eigs = np.sort((sv ** 2)[sv > 0])
    if eigs.size < 10:
        return float("nan")
    try:
        import powerlaw
        fit = powerlaw.Fit(eigs, verbose=False)
        return float(fit.alpha)
    except Exception:
        return float("nan")


# --------------------------------------------------------------------------
# activation / gradient features
# --------------------------------------------------------------------------
def _flatten_examples(a: torch.Tensor) -> torch.Tensor | None:
    """X_l in R^{n x f}: 4D conv outputs are averaged over spatial dims."""
    if a.dim() == 4:
        return a.mean(dim=(2, 3))
    if a.dim() == 2:
        return a
    if a.dim() == 3:
        return a.mean(dim=1)
    return None


def _linear_cka(x: torch.Tensor, y: torch.Tensor) -> float:
    x = x - x.mean(0, keepdim=True)
    y = y - y.mean(0, keepdim=True)
    num = torch.linalg.matrix_norm(y.T @ x) ** 2
    den = torch.linalg.matrix_norm(x.T @ x) * torch.linalg.matrix_norm(y.T @ y)
    if den.item() == 0.0:
        return 0.0
    return float((num / den).item())


def _taylor(a: torch.Tensor, g: torch.Tensor) -> float:
    """
    mean | A * dL/dA |.  For 4D outputs: average over batch and spatial dims
    first, then over channels; otherwise over the batch dim then the rest.
    """
    t = (a * g).abs()
    if t.dim() == 4:
        return float(t.mean(dim=(0, 2, 3)).mean().item())
    return float(t.mean(dim=0).mean().item())


# --------------------------------------------------------------------------
# main entry point
# --------------------------------------------------------------------------
def analyze(model: nn.Module,
            batches: list[tuple[torch.Tensor, torch.Tensor]],
            loss_fn,
            device: torch.device,
            sensitivity_batches: int = 5) -> dict[str, float]:
    """
    Compute the seven statistics for every analyzed layer and return the
    layer-mean of each, i.e. one LAYER_STATS_MEAN_BY_EPOCH row.

    batches : cached analysis minibatches; batches[0] drives the
              activation/gradient features, the first `sensitivity_batches`
              drive sensitivity.  Pass the same batches at every checkpoint
              so that differences across epochs come from the weights only.
    """
    model = model.to(device)
    was_training = model.training
    model.eval()                     # deterministic activations; grads still flow

    layers = [(n, m) for n, m in model.named_modules()
              if isinstance(m, TARGET_TYPES) and getattr(m, "weight", None) is not None]
    if not layers:
        return {s: float("nan") for s in STATS}

    per_layer: dict[str, dict[str, float]] = {n: {} for n, _ in layers}

    # ---- weight-only features -------------------------------------------
    for n, m in layers:
        per_layer[n]["rank_ratio"] = rank_ratio(m.weight)
        per_layer[n]["ww_alpha"] = ww_alpha(m.weight)

    # ---- one forward/backward for activation and gradient features ------
    acts: dict[str, torch.Tensor] = {}
    grads: dict[str, torch.Tensor] = {}
    handles = []

    def make_hook(name):
        def hook(_mod, _inp, out):
            if not isinstance(out, torch.Tensor):
                return
            acts[name] = out
            out.retain_grad()
            out.register_hook(lambda g, name=name: grads.__setitem__(name, g.detach()))
        return hook

    for n, m in layers:
        handles.append(m.register_forward_hook(make_hook(n)))

    x0, y0 = batches[0]
    x0, y0 = x0.to(device), y0.to(device)
    model.zero_grad(set_to_none=True)
    out = model(x0)
    out = out[1] if isinstance(out, (tuple, list)) else out     # xautodl nets
    loss = loss_fn(out, y0)
    loss.backward()
    for h in handles:
        h.remove()

    for n, m in layers:
        a = acts.get(n)
        g = grads.get(n)
        per_layer[n]["grad_norm"] = (float(m.weight.grad.detach().norm().item())
                                     if m.weight.grad is not None else float("nan"))
        if a is None:
            per_layer[n]["dead_frac"] = float("nan")
            per_layer[n]["taylor_imp"] = float("nan")
            continue
        ad = a.detach()
        per_layer[n]["dead_frac"] = float((ad.abs() < DEAD_EPS).float().mean().item())
        per_layer[n]["taylor_imp"] = (_taylor(ad, g) if g is not None else float("nan"))

    # ---- CKA redundancy over the same forward pass ----------------------
    reps = {}
    for n, _ in layers:
        a = acts.get(n)
        if a is None:
            continue
        X = _flatten_examples(a.detach().float())
        if X is not None and X.shape[0] > 1 and X.shape[1] > 0:
            reps[n] = X
    names = list(reps)
    if len(names) > 1:
        for i, n in enumerate(names):
            sims = [_linear_cka(reps[n], reps[j]) for k, j in enumerate(names) if k != i]
            per_layer[n]["cka_redund"] = float(np.mean(sims))
    acts.clear(); grads.clear(); reps.clear()
    model.zero_grad(set_to_none=True)

    # ---- sensitivity: zero one layer at a time --------------------------
    use = batches[:max(1, sensitivity_batches)]
    with torch.no_grad():
        base = float(np.mean([
            loss_fn(_fwd(model, xb.to(device)), yb.to(device)).item() for xb, yb in use]))
        for n, m in layers:
            w_bak = m.weight.detach().clone()
            b_bak = m.bias.detach().clone() if getattr(m, "bias", None) is not None else None
            m.weight.zero_()
            if b_bak is not None:
                m.bias.zero_()
            zer = float(np.mean([
                loss_fn(_fwd(model, xb.to(device)), yb.to(device)).item() for xb, yb in use]))
            m.weight.copy_(w_bak)
            if b_bak is not None:
                m.bias.copy_(b_bak)
            per_layer[n]["sensitivity"] = (zer - base) / max(abs(base), 1e-8)

    if was_training:
        model.train()

    # ---- run-level mean over finite layer values ------------------------
    row = {}
    for s in STATS:
        vals = [v[s] for v in per_layer.values() if s in v and np.isfinite(v[s])]
        row[s] = float(np.mean(vals)) if vals else float("nan")
    return row


def _fwd(model, x):
    out = model(x)
    return out[1] if isinstance(out, (tuple, list)) else out


def to_tsv(rows: dict[int, dict[str, float]], stats=tuple(STATS)) -> str:
    """Render {epoch: {stat: value}} as the tab-separated prompt block."""
    out = ["epoch\t" + "\t".join(stats)]
    for e in sorted(rows):
        vals = [f"{rows[e].get(s, float('nan')):.6g}" for s in stats]
        out.append(str(e) + "\t" + "\t".join(vals))
    return "\n".join(out)
