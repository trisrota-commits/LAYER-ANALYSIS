#!/usr/bin/env python3
"""
Stage 1 -- build a LEMUR-schema snapshot from NAS-Bench-201 / NATS-Bench.

For each sampled architecture it produces one JSON record with exactly the
fields the LEMUR predictor snapshot carries, so that stages 2 and 3 are
corpus-agnostic:

  id, task, dataset, metric, nn, prm,
  accuracy_epoch_1..3, best_accuracy, epochs_to_best, total_epochs,
  layer_stats            (tab-separated, one row per early checkpoint)

Targets and early accuracies come from the benchmark tables -- they are the
corpus's own ground truth.  Only the layer statistics need weights, obtained
one of two ways:

  --weights train      (default) train the architecture for 3 epochs with the
                       benchmark's own recipe and analyze after each epoch.
                       Faithful to the paper's epoch-1/2/3 checkpoints.
                       Cost: ~2-4 GPU-min per architecture on CIFAR.

  --weights api        read the released trained parameters via
                       api.get_net_param(...) and analyze that single
                       checkpoint, replicated across the three rows.
                       Nearly free, but the checkpoint is the benchmark's
                       12- or 200-epoch model, not epoch 1-3.  Use only as a
                       cheap smoke test and say so in the write-up.

Requirements
  pip install torch torchvision nats_bench xautodl powerlaw
  NATS-Bench topology file (NATS-tss-v1_0-3ffb9-simple) or
  NAS-Bench-201-v1_1-096897.pth, and the dataset itself for --weights train.

Example
  python3 collect.py --bench ~/NATS-tss-v1_0-3ffb9-simple \
      --dataset cifar10-valid --n 300 --data-root ~/data \
      --out nb201_cifar10_snapshot.jsonl
"""
from __future__ import annotations

import argparse, hashlib, json, os, random, sys, time

import numpy as np
import torch
import torch.nn as nn

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from layer_stats import analyze, to_tsv, STATS      # noqa: E402

EARLY_EPOCHS = (1, 2, 3)

# NAS-Bench-201 training recipe (Dong & Yang, ICLR 2020, Table 7)
RECIPE = dict(lr=0.1, momentum=0.9, weight_decay=5e-4, nesterov=True,
              batch=256, total_epochs=200)

DSET = {                      # benchmark name -> (torchvision name, #classes)
    "cifar10-valid": ("cifar10", 10),
    "cifar10":       ("cifar10", 10),
    "cifar100":      ("cifar100", 100),
    "ImageNet16-120": ("imagenet16-120", 120),
}


# --------------------------------------------------------------------------
def open_api(path: str):
    try:
        from nats_bench import create
        return create(path, "tss", fast_mode=True, verbose=False), "nats"
    except Exception:
        from nas_201_api import NASBench201API
        return NASBench201API(path, verbose=False), "n201"


def arch_family(arch_str: str) -> str:
    """
    Split analogue of the paper's architecture-family split: group cells by
    their operation multiset, so no two architectures sharing an operation
    mix can straddle train and test.
    """
    ops = [p.split("~")[0] for seg in arch_str.split("+")
           for p in seg.strip("|").split("|") if p]
    return "|".join(sorted(ops))


def curve(api, idx: int, dataset: str, hp: str = "200"):
    """Per-epoch validation accuracy for one architecture."""
    accs = []
    for e in range(int(hp)):
        try:
            info = api.get_more_info(idx, dataset, iepoch=e, hp=hp, is_random=False)
        except TypeError:                             # older nas_201_api
            info = api.get_more_info(idx, dataset, e, False)
        a = info.get("valid-accuracy", info.get("valtest-accuracy"))
        if a is None:
            a = info.get("test-accuracy")
        accs.append(float(a))
    return accs


def build_net(api, idx: int, dataset: str, device):
    from xautodl.models import get_cell_based_tiny_net
    cfg = api.get_net_config(idx, dataset)
    return get_cell_based_tiny_net(cfg).to(device)


def loaders(dataset: str, root: str, batch: int, workers: int):
    import torchvision as tv
    import torchvision.transforms as T
    name, ncls = DSET[dataset]
    if name.startswith("cifar"):
        mean, std = ((0.4914, 0.4822, 0.4465), (0.2470, 0.2435, 0.2616))
        tr = T.Compose([T.RandomCrop(32, padding=4), T.RandomHorizontalFlip(),
                        T.ToTensor(), T.Normalize(mean, std)])
        te = T.Compose([T.ToTensor(), T.Normalize(mean, std)])
        cls = tv.datasets.CIFAR10 if name == "cifar10" else tv.datasets.CIFAR100
        train = cls(root, train=True, download=True, transform=tr)
        test = cls(root, train=True, download=True, transform=te)
    else:
        raise SystemExit("ImageNet16-120 needs the ImageNet16 loader from xautodl; "
                         "point --data-root at it and extend loaders().")
    g = torch.Generator().manual_seed(0)
    tl = torch.utils.data.DataLoader(train, batch_size=batch, shuffle=True,
                                     num_workers=workers, pin_memory=True,
                                     drop_last=True, generator=g)
    # fixed analysis batches, identical at every checkpoint and architecture
    al = torch.utils.data.DataLoader(torch.utils.data.Subset(test, list(range(2048))),
                                     batch_size=128, shuffle=False, num_workers=0)
    return tl, al, ncls


def train_and_analyze(net, train_loader, analysis_batches, device, epochs=3):
    """Train with the benchmark recipe, analyzing after each early epoch."""
    crit = nn.CrossEntropyLoss()
    opt = torch.optim.SGD(net.parameters(), lr=RECIPE["lr"],
                          momentum=RECIPE["momentum"], nesterov=RECIPE["nesterov"],
                          weight_decay=RECIPE["weight_decay"])
    sched = torch.optim.lr_scheduler.CosineAnnealingLR(
        opt, T_max=RECIPE["total_epochs"], eta_min=0.0)
    rows, measured = {}, {}
    for ep in range(1, epochs + 1):
        net.train()
        correct = seen = 0
        for x, y in train_loader:
            x, y = x.to(device, non_blocking=True), y.to(device, non_blocking=True)
            opt.zero_grad(set_to_none=True)
            out = net(x)
            out = out[1] if isinstance(out, (tuple, list)) else out
            loss = crit(out, y)
            loss.backward()
            nn.utils.clip_grad_norm_(net.parameters(), 5.0)
            opt.step()
            correct += (out.argmax(1) == y).sum().item(); seen += y.numel()
        sched.step()
        measured[ep] = 100.0 * correct / max(seen, 1)
        rows[ep] = analyze(net, analysis_batches, crit, device)
    return rows, measured


# --------------------------------------------------------------------------
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--bench", required=True, help="NATS-Bench / NB201 file")
    ap.add_argument("--dataset", default="cifar10-valid", choices=list(DSET))
    ap.add_argument("--n", type=int, default=300, help="architectures to sample")
    ap.add_argument("--sample-seed", type=int, default=2026)
    ap.add_argument("--weights", choices=["train", "api"], default="train")
    ap.add_argument("--data-root", default="./data")
    ap.add_argument("--workers", type=int, default=4)
    ap.add_argument("--hp", default="200")
    ap.add_argument("--out", default="nb201_snapshot.jsonl")
    ap.add_argument("--resume", action="store_true",
                    help="skip architectures already present in --out")
    a = ap.parse_args()

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    api, flavour = open_api(a.bench)
    total = len(api)
    rng = random.Random(a.sample_seed)
    idxs = sorted(rng.sample(range(total), min(a.n, total)))

    done = set()
    if a.resume and os.path.exists(a.out):
        for line in open(a.out):
            try: done.add(json.loads(line)["arch_index"])
            except Exception: pass
        print(f"resuming, {len(done)} records already written")

    train_loader = analysis_batches = None
    if a.weights == "train":
        tl, al, _ = loaders(a.dataset, a.data_root, RECIPE["batch"], a.workers)
        train_loader = tl
        analysis_batches = [(x, y) for x, y in al][:5]     # cached once, reused

    fh = open(a.out, "a" if a.resume else "w")
    t0 = time.time()
    for k, idx in enumerate(idxs):
        if idx in done:
            continue
        arch = api.arch(idx) if hasattr(api, "arch") else api.query_meta_info_by_index(idx).arch_str
        try:
            acc = curve(api, idx, a.dataset, a.hp)
        except Exception as e:
            print(f"[{idx}] curve unavailable ({e}); skipped"); continue
        best = float(max(acc)); best_ep = int(np.argmax(acc)) + 1

        net = build_net(api, idx, a.dataset, device)
        if a.weights == "train":
            rows, measured = train_and_analyze(net, train_loader, analysis_batches, device)
        else:
            try:
                params = api.get_net_param(idx, a.dataset, None, hp=a.hp)
                params = list(params.values())[0] if isinstance(params, dict) else params
                net.load_state_dict(params)
            except Exception as e:
                print(f"[{idx}] no released weights ({e}); skipped"); continue
            tl, al, _ = loaders(a.dataset, a.data_root, RECIPE["batch"], 0) \
                if analysis_batches is None else (None, None, None)
            if analysis_batches is None:
                analysis_batches = [(x, y) for x, y in al][:5]
            one = analyze(net, analysis_batches, nn.CrossEntropyLoss(), device)
            rows = {e: one for e in EARLY_EPOCHS}
            measured = {}

        rec = dict(
            id=hashlib.md5(f"nb201:{a.dataset}:{idx}".encode()).hexdigest(),
            arch_index=idx, arch_str=arch, arch_family=arch_family(arch),
            task="img-classification", dataset=a.dataset, metric="acc",
            nn=f"nb201-{idx:05d}",
            prm=json.dumps(dict(batch=RECIPE["batch"], dataset=a.dataset,
                                epoch_max=int(a.hp), lr=RECIPE["lr"], metric="acc",
                                momentum=RECIPE["momentum"], model=f"nb201-{idx:05d}",
                                task="img-classification", weight_decay=RECIPE["weight_decay"])),
            accuracy_epoch_1=float(acc[0]), accuracy_epoch_2=float(acc[1]),
            accuracy_epoch_3=float(acc[2]),
            measured_early_accuracy={str(k2): v for k2, v in measured.items()},
            best_accuracy=best, epochs_to_best=best_ep, total_epochs=int(a.hp),
            layer_stats=to_tsv(rows),
            weights_source=a.weights)
        fh.write(json.dumps(rec) + "\n"); fh.flush()
        el = time.time() - t0
        print(f"[{k+1}/{len(idxs)}] idx={idx} best={best:.2f}@{best_ep} "
              f"taylor_e3={rows[3]['taylor_imp']:.4g}  {el/60:.1f} min elapsed")
    fh.close()
    print(f"wrote {a.out}")


if __name__ == "__main__":
    main()
