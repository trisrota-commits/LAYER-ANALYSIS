NAS-Bench-201 combined local evidence package

Scope: locally available NB201/NAS201 evidence directories and original archives, plus nb201_v1 scripts. This is an evidence collection, not a self-contained training environment or proof of complete cluster-log coverage. No thesis source modified.

FINAL QWEN ANALYSES
CIFAR-10-valid and CIFAR-100: evidence/nb201-qwen-primary-v1/
ImageNet16-120: evidence/nb201-imagenet16-primary-v1/analysis/
Original CIFAR Qwen exports: evidence/nb201-qwen-results-v1/
Original ImageNet16 exports: evidence/nb201-imagenet16-primary-v1/source/
Classical comparisons: evidence/nb201-classical-matched-v1/
Scripts: nb201_v1/primary_endpoint.py and related files.

HISTORICAL / PREPARATION MATERIAL
Pilot results, input v1/v2, collected snapshots and prepared Job bundles remain separately named. Prepared Jobs are not execution proof. Earlier summaries can predate the completed ImageNet16 analysis; consult final results.json files and receipts. No classical ImageNet16 result is asserted by this inventory.

BOUNDARIES
Primary MAE population uses targets >=20 percent; all-record descriptive summaries are separate. ImageNet16 mixed model required Powell fallback and has a boundary warning. Legacy best_accuracy field names do not redefine fixed-final targets. Existing source archives/receipts are preserved. Full pod stdout is not guaranteed present. No model checkpoints or image datasets were discovered in the packaged directories.
