import argparse
import csv
import hashlib
import json
import math
import re
import sys
from collections import defaultdict
from pathlib import Path

FEATURES = [f"accuracy_{e}" for e in (1, 2, 3)] + [f"taylor_{e}" for e in (1, 2, 3)] + ["log_params", "depth"]
SEEDS = list(range(42, 48))

def require(ok, message):
    if not ok:
        raise ValueError(message)

def load_rows(path):
    return [json.loads(line) for line in path.read_text().splitlines() if line.strip()]

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def number(value):
    if value is None or str(value).strip().lower() in {"na", "nan", "none", "null", "n/a", ""}:
        return None
    value = float(value)
    return value if math.isfinite(value) else None

def early(value):
    value = number(value)
    return None if value is None else round(value, 6)

def taylor(table):
    lines = [line.split() for line in table.splitlines() if line.strip()]
    column = lines[0].index("taylor_imp")
    values = {}
    for row in lines[1:]:
        epoch = int(row[0])
        require(epoch not in values, "Duplicate Taylor epoch")
        values[epoch] = number(row[column])
    require(set(values) == {1, 2, 3}, "Expected exactly Taylor epochs 1,2,3")
    return tuple(values[e] for e in (1, 2, 3))

def raw_key(row):
    return (row["nn"], row["dataset"], row["task"], row["metric"], int(row["total_epochs"]),
            *(early(row[f"accuracy_epoch_{e}"]) for e in (1, 2, 3)), *taylor(row["layer_stats"]))

def prompt_key(row):
    users = [m["content"] for m in row["messages"] if m["role"] == "user"]
    require(len(users) == 1, "Expected one user message")
    text = users[0]
    def field(name):
        values = re.findall(rf"^{re.escape(name)}:[ \t]*(.+)$", text, re.MULTILINE)
        require(len(values) == 1, f"Missing/duplicate prompt field: {name}")
        return values[0].strip()
    table = re.search(r"^epoch[ \t]+taylor_imp[^\n]*\n((?:[ \t]*\d+[ \t]+[^\n]+\n?)+)", text, re.MULTILINE)
    require(table is not None, "Missing Taylor table")
    return (row["architecture_id"], field("dataset"), field("task"), field("metric"), int(field("max_epochs")),
            *(early(field(f"epoch_{e}_accuracy")) for e in (1, 2, 3)),
            *taylor("epoch\ttaylor_imp\n" + table.group(1)))

def prepare(root):
    source = root / "out/acc_predict_rebuilt_probe/llm_finetuning_data.jsonl"
    cache_path = root / "out/generalization_prepare_cache/out/acc_predict/proxy_cache.jsonl"
    prompt_dir = root / "zcp-off-toggle-refit7-v1/prompts/3acc-taylor"
    contract_path = root / "zcp-off-toggle-refit7-v1/contract.json"
    run = json.loads(contract_path.read_text())["runs"]["3acc-taylor-s42"]
    paths = [source, cache_path, contract_path]
    index, cache = defaultdict(list), defaultdict(list)
    for row in load_rows(source):
        index[raw_key(row)].append(row)
    for row in load_rows(cache_path):
        cache[(row.get("nn"), row.get("dataset"))].append(row)
    data, manifest, summary = {}, [], {}
    all_ids, arch_sets = set(), {}
    for split, count in (("train", 978), ("val", 58), ("test", 115)):
        path = prompt_dir / f"{split}_llm_dataset.jsonl"
        paths.append(path)
        require(sha(path) == run["input_sha256"][path.name], f"{split}: contract hash mismatch")
        rows = load_rows(path)
        require(len(rows) == count, f"{split}: wrong split count")
        x, y, ids, datasets = [], [], [], []
        arch_sets[split] = set()
        for position, row in enumerate(rows):
            key = prompt_key(row)
            matches = index.get(key, [])
            require(len(matches) == 1, f"{split}/{position}: {len(matches)} raw matches; refusing selection")
            raw = matches[0]
            rid = raw["id"]
            require(isinstance(rid, str) and rid and rid not in all_ids, f"Repeated/invalid raw ID: {rid}")
            all_ids.add(rid)
            answers = [m["content"] for m in row["messages"] if m["role"] == "assistant"]
            require(len(answers) == 1, "Expected one saved answer")
            answer = json.loads(answers[0])
            target, raw_target = float(answer["best_accuracy"]), float(raw["best_accuracy"])
            require(math.isfinite(raw_target) and 0 <= raw_target <= 100, "Invalid raw target")
            require(target == round(raw_target, 2), f"{split}/{position}: target differs beyond exact two-decimal serialization")
            require(int(answer["best_epoch"]) == max(1, min(int(raw["epochs_to_best"]), int(raw["total_epochs"]))), "Best-epoch mismatch")
            cached = cache.get((key[0], key[1]), [])
            static = {(number(r.get("log_params")), number(r.get("depth"))) for r in cached}
            require(len(static) <= 1, f"Conflicting static features: {key[:2]}")
            lp, depth = next(iter(static)) if static else (None, None)
            require(lp is None or lp >= 0, "Invalid log_params")
            require(depth is None or (depth > 0 and depth.is_integer()), "Invalid depth")
            values = list(key[5:]) + [lp, depth]
            require(len(values) == 8, "Feature width mismatch")
            x.append(values)
            y.append(target)
            ids.append(rid)
            datasets.append(key[1])
            arch_sets[split].add(key[0])
            manifest.append(dict(split=split, position=position, record_id=rid, architecture_id=key[0], dataset=key[1],
                                 target=target, raw_target=raw_target, **dict(zip(FEATURES, values))))
        data[split] = dict(x=x, y=y, ids=ids, datasets=datasets)
        missing = {name: sum(row[j] is None for row in x) for j, name in enumerate(FEATURES)}
        summary[split] = dict(records=len(rows), missing=missing)
    for a, b in (("train", "val"), ("train", "test"), ("val", "test")):
        require(not arch_sets[a] & arch_sets[b], f"Architecture overlap: {a}/{b}")
    reference = {}
    for seed in SEEDS:
        owner = "zcp-off-toggle-refit7-v1" if seed <= 44 else "taylor-3acc-zcp-off-seeds45-47-v1"
        result = root / owner / "results" / f"3acc-taylor-s{seed}"
        done_path = result / "refit_complete.json"
        done = json.loads(done_path.read_text())
        require(done["training_records"] == 1036 and done["epochs"] == 7 and done["run"] == f"3acc-taylor-s{seed}", "Reference refit mismatch")
        prediction_path = result / "test_predictions.csv"
        with prediction_path.open(newline="") as f:
            rows = list(csv.DictReader(f))
        require(len(rows) == 115, f"Reference s{seed}: wrong prediction count")
        predictions = []
        for i, row in enumerate(rows):
            require(int(row["idx"]) == i, "Reference index/order mismatch")
            require(row["dataset"] == data["test"]["datasets"][i], "Reference dataset mismatch")
            require(float(row["gt_best_accuracy"]) == data["test"]["y"][i], "Reference target mismatch")
            value = number(row["pred_best_accuracy"])
            require(value is not None, f"Reference s{seed}: missing prediction; requires explicit coverage policy")
            predictions.append(value)
        reference[seed] = predictions
        paths.extend([done_path, prediction_path])
    receipt = dict(features=FEATURES, seeds=SEEDS, splits=summary,
                   input_sha256={str(p.relative_to(root)): sha(p) for p in paths},
                   target_policy="Fit/evaluate saved two-decimal Qwen targets; retain original raw targets in records.csv",
                   preprocessing="Training-only median imputation; training-only standardization for ridge; frozen during train+val refit",
                   comparison_note="Classical has requested static log_params/depth; saved Taylor/OFF Qwen lacks these and contains task/dataset/budget metadata",
                   selection="Minimum validation RMSE per model/seed; grid order breaks ties; no test-based selection")
    return data, manifest, receipt, reference

def save_json(path, obj):
    with path.open("x") as f:
        json.dump(obj, f, indent=2, allow_nan=False)

def save_csv(path, fields, rows):
    with path.open("x", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)

def run_fits(data, manifest, receipt, reference, output):
    import importlib.metadata
    import numpy as np
    from scipy import stats
    from sklearn.ensemble import RandomForestRegressor, HistGradientBoostingRegressor
    from sklearn.impute import SimpleImputer
    from sklearn.linear_model import Ridge
    from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score
    from sklearn.model_selection import ParameterGrid
    from sklearn.preprocessing import StandardScaler
    require(not output.exists(), f"Refusing existing output: {output}")
    arrays = {s: np.array(d["x"], dtype=float) for s, d in data.items()}
    ys = {s: np.array(d["y"], dtype=float) for s, d in data.items()}
    require(not np.isnan(arrays["train"]).all(axis=0).any(), "All-missing training feature")
    imputer = SimpleImputer(strategy="median")
    imputer.fit(arrays["train"])
    arrays = {s: imputer.transform(x) for s, x in arrays.items()}
    require(all(np.isfinite(x).all() for x in arrays.values()), "Non-finite features")
    scaler = StandardScaler().fit(arrays["train"])
    scaled = {s: scaler.transform(x) for s, x in arrays.items()}
    grids = {
        "ridge": list(ParameterGrid({"alpha": [0.01, 0.1, 1.0, 10.0, 100.0, 1000.0]})),
        "random_forest": list(ParameterGrid({"max_depth": [None, 12], "min_samples_leaf": [1, 3, 8], "max_features": [1.0, 0.75]})),
        "hist_gradient_boosting": list(ParameterGrid({"learning_rate": [0.03, 0.1], "max_leaf_nodes": [7, 15], "l2_regularization": [0.0, 1.0]})),
    }
    def estimator(name, seed, params):
        if name == "ridge":
            return Ridge(solver="svd", **params)
        if name == "random_forest":
            return RandomForestRegressor(n_estimators=200, random_state=seed, n_jobs=1, **params)
        return HistGradientBoostingRegressor(max_iter=200, early_stopping=False, random_state=seed, **params)
    def metrics(y, pred):
        require(np.isfinite(pred).all(), "Non-finite predictions")
        result = dict(RMSE=float(np.sqrt(mean_squared_error(y, pred))), MAE=float(mean_absolute_error(y, pred)),
                      Pearson=float(stats.pearsonr(y, pred).statistic), Spearman=float(stats.spearmanr(y, pred).statistic), R2=float(r2_score(y, pred)))
        require(all(math.isfinite(v) for v in result.values()), "Undefined metric (possibly constant predictions)")
        return result
    output.mkdir(parents=True, exist_ok=False)
    receipt.update(packages={p: importlib.metadata.version(p) for p in ("numpy", "scipy", "scikit-learn")},
                   python=sys.version, grids=grids, imputation_medians=imputer.statistics_.tolist(),
                   ridge_scaler_mean=scaler.mean_.tolist(), ridge_scaler_scale=scaler.scale_.tolist(),
                   script_sha256=sha(Path(__file__)))
    save_json(output / "contract.json", receipt)
    save_csv(output / "records.csv", list(manifest[0]), manifest)
    all_metrics = []
    def persist(name, seed, pred):
        rows = [dict(record_id=rid, prediction=float(p), target=float(y), seed=seed)
                for rid, p, y in zip(data["test"]["ids"], pred, ys["test"])]
        path = output / f"{name}-s{seed}-predictions.csv"
        save_csv(path, ["record_id", "prediction", "target", "seed"], rows)
        with path.open(newline="") as f:
            checked = list(csv.DictReader(f))
        require([r["record_id"] for r in checked] == data["test"]["ids"], "CSV ID verification failed")
        require([float(r["target"]) for r in checked] == data["test"]["y"], "CSV target verification failed")
        require([float(r["prediction"]) for r in checked] == [float(p) for p in pred], "CSV prediction verification failed")
        result = dict(model=name, seed=seed, **metrics(ys["test"], pred))
        all_metrics.append(result)
        save_json(output / f"{name}-s{seed}-metrics.json", result)
        print(json.dumps(result), flush=True)
    for name, grid in grids.items():
        x = scaled if name == "ridge" else arrays
        final_x = np.concatenate([x["train"], x["val"]])
        final_y = np.concatenate([ys["train"], ys["val"]])
        for seed in SEEDS:
            trials = []
            for params in grid:
                model = estimator(name, seed, params).fit(x["train"], ys["train"])
                score = float(np.sqrt(mean_squared_error(ys["val"], model.predict(x["val"]))))
                require(math.isfinite(score), "Non-finite validation score")
                trials.append(dict(params=params, validation_RMSE=score))
            best = min(trials, key=lambda t: t["validation_RMSE"])
            save_json(output / f"{name}-s{seed}-selection.json", dict(selected=best, trials=trials))
            model = estimator(name, seed, best["params"]).fit(final_x, final_y)
            persist(name, seed, model.predict(x["test"]))
    for seed in SEEDS:
        persist("qwen_reference", seed, reference[seed])
    save_csv(output / "metrics_by_seed.csv", list(all_metrics[0]), all_metrics)
    summaries = []
    for name in [*grids, "qwen_reference"]:
        group = [row for row in all_metrics if row["model"] == name]
        require(len(group) == 6, "Incomplete seeds")
        for metric in ("RMSE", "MAE", "Pearson", "Spearman", "R2"):
            values = np.array([row[metric] for row in group])
            mean = float(values.mean())
            half = float(stats.t.ppf(0.975, 5) * values.std(ddof=1) / np.sqrt(6))
            summaries.append(dict(model=name, metric=metric, mean=mean, ci_low=mean-half, ci_high=mean+half))
    save_csv(output / "summary.csv", list(summaries[0]), summaries)
    hashes = {p.name: sha(p) for p in output.iterdir() if p.is_file()}
    save_json(output / "complete.json", dict(status="complete", seeds=SEEDS, final_fit_records=1036, test_records=115, files_sha256=hashes))
    print("COMPLETE:", output / "summary.csv", flush=True)

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, default=Path("/shared/ssd/home/b-t-bose/lmur"))
    parser.add_argument("--output", type=Path)
    parser.add_argument("--run", action="store_true")
    args = parser.parse_args()
    if args.run:
        require(args.output is not None, "--run requires --output")
        require(not args.output.exists(), f"Refusing existing output: {args.output}")
    data, manifest, receipt, reference = prepare(args.root)
    print("PREFLIGHT PASS", json.dumps(receipt["splits"]), flush=True)
    if args.run:
        run_fits(data, manifest, receipt, reference, args.output)
    else:
        print("Read-only preflight only; no output files created.")

if __name__ == "__main__":
    main()
