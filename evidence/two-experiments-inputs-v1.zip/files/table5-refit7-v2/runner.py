from dataclasses import fields
import gc
import hashlib
import inspect
import json
import math
import sys
from pathlib import Path

EPOCHS = 7

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def main():
    mode, contract_path, key = sys.argv[1:]
    assert mode in ('train', 'test')
    contract = json.loads(Path(contract_path).read_text())
    assert contract['epochs'] == EPOCHS
    run = contract['runs'][key]
    root = Path(run['data'])
    out = Path(run['output'])
    base = Path(contract['base'])
    selected = Path(run['selected'])
    model_path = out / 'tuned_model'

    for path, digest in contract['source_sha256'].items():
        assert sha(Path(path)) == digest, f'Source changed: {path}'
    for name, digest in run['input_sha256'].items():
        assert sha(root / name) == digest, f'Input changed: {root / name}'
    for name, digest in run['selection_sha256'].items():
        assert sha(selected / name) == digest, f'Selection metadata changed: {name}'
    assert not (base / 'adapter_config.json').exists(), 'Base path is an adapter'
    index = json.loads((base / 'model.safetensors.index.json').read_text())
    for name in ('config.json', 'tokenizer.json', *set(index['weight_map'].values())):
        p = base / name
        assert p.is_file() and p.stat().st_size > 0, p

    if mode == 'test':
        done = json.loads((out / 'refit_complete.json').read_text())
        assert done['epochs'] == EPOCHS and done['training_records'] == 1036
        assert done['run'] == key
        for name, digest in done['model_sha256'].items():
            assert sha(model_path / name) == digest, f'Refit model changed: {name}'
        # Exclusive marker: never automatically repeat test inference.
        with (out / 'test_started.json').open('x') as f:
            json.dump({'run': key, 'test': str(root / 'test_llm_dataset.jsonl')}, f)
        from ab.gpt.act.acc_predictor import eval as evaluator
        metrics = evaluator.test_model(
            model_path=model_path,
            data_path=root / 'test_llm_dataset.jsonl',
            output_path=out / 'test_predictions.csv',
            metrics_path=out / 'test_metrics.log',
        )
        (out / 'test_metrics.json').write_text(json.dumps(metrics, indent=2))
        assert metrics['n_samples'] == 115, metrics
        for name in ('test_predictions.csv', 'test_metrics.log'):
            assert (out / name).is_file() and (out / name).stat().st_size > 0, name
        # Coverage is reported honestly, not used to retune or rerun a model.
        result = {
            'run': key, 'epochs': EPOCHS, 'n_samples': metrics['n_samples'],
            'n_valid': metrics['n_valid'], 'parse_failures': metrics['parse_failures'],
        }
        (out / 'test_complete.json').write_text(json.dumps(result, indent=2))
        print('FINAL_REFIT_TEST_COMPLETE', json.dumps(result), flush=True)
        return

    assert not out.exists(), f'Refusing to overwrite: {out}'
    from ab.gpt.act.acc_predictor import train as t
    from ab.gpt.act.acc_predictor import config
    from ab.gpt.act.acc_predictor import eval as evaluator

    defaults = {k: v.default for k, v in inspect.signature(t.train_model).parameters.items()}
    assert defaults['num_epochs'] == 20
    assert defaults['early_stopping_patience'] == 3
    assert t.MAX_STEPS == 0
    assert t.torch.cuda.is_available(), 'CUDA unavailable'
    inspect.signature(evaluator.test_model).bind(
        model_path=model_path, data_path=root / 'test_llm_dataset.jsonl',
        output_path=out / 'test_predictions.csv', metrics_path=out / 'test_metrics.log',
    )

    # Only deserialize our own saved Stage-1 TrainingArguments, never model weights.
    args = t.torch.load(selected / 'training_args.bin', map_location='cpu', weights_only=False)
    expected = {
        'learning_rate': defaults['learning_rate'],
        'per_device_train_batch_size': defaults['batch_size'],
        'gradient_accumulation_steps': defaults['gradient_accumulation_steps'],
        'weight_decay': t.WEIGHT_DECAY,
        'max_grad_norm': t.MAX_GRAD_NORM,
        'seed': run['seed'],
        'num_train_epochs': 20,
    }
    for name, value in expected.items():
        assert getattr(args, name) == value, (name, getattr(args, name), value)
    assert args.max_steps <= 0 and args.load_best_model_at_end
    assert getattr(args.optim, 'value', args.optim) == 'adamw_8bit'
    assert getattr(args.lr_scheduler_type, 'value', args.lr_scheduler_type) == 'linear'
    assert args.metric_for_best_model == 'eval_loss'
    seq = defaults['max_seq_len']
    saved_lengths = {
        name: getattr(args, name)
        for name in ('max_seq_length', 'max_length')
        if getattr(args, name, None) is not None
    }
    assert saved_lengths, 'No saved trainer sequence-length settings'
    print('MODEL_CONTEXT:', seq, 'SAVED_TRAINER_LENGTHS:', saved_lengths, flush=True)

    adapter = json.loads((selected / 'adapter_config.json').read_text())
    targets = ['q_proj', 'k_proj', 'v_proj', 'o_proj', 'gate_proj', 'up_proj', 'down_proj']
    assert adapter['r'] == defaults['lora_r']
    assert adapter['lora_alpha'] == defaults['lora_alpha']
    assert adapter['lora_dropout'] == t.LORA_DROPOUT
    assert set(adapter['target_modules']) == set(targets)
    assert adapter['bias'] == 'none' and not adapter.get('use_rslora', False)
    assert adapter.get('base_model_name_or_path') in (str(base), config.MODEL_NAME)

    records = []
    ids = {}
    for split, count in (('train', 978), ('val', 58), ('test', 115)):
        rows = [json.loads(x) for x in (root / f'{split}_llm_dataset.jsonl').read_text().splitlines() if x.strip()]
        assert len(rows) == count
        assert all(r.get('architecture_id') for r in rows)
        ids[split] = {str(r['architecture_id']) for r in rows}
        if split != 'test':
            records.extend(rows)
    assert not (ids['train'] & ids['val'])
    assert not ((ids['train'] | ids['val']) & ids['test'])
    assert len(records) == 1036

    batch = args.per_device_train_batch_size
    accumulation = args.gradient_accumulation_steps
    selection_steps = math.ceil(978 / (batch * accumulation)) * 20
    assert args.warmup_steps == max(1, int(selection_steps * defaults['warmup_ratio']))
    # Reuse saved effective settings; change only the final-refit requirements.
    args.output_dir = str(model_path)
    args.logging_dir = str(out / 'trainer_logs')
    args.num_train_epochs = EPOCHS
    args.warmup_steps = max(1, int(math.ceil(1036 / (batch * accumulation)) * EPOCHS * defaults['warmup_ratio']))
    args.eval_strategy = type(args.eval_strategy)('no')
    args.do_eval = False
    args.load_best_model_at_end = False
    args.metric_for_best_model = None
    args.greater_is_better = None
    if hasattr(args, 'evaluation_strategy'):
        args.evaluation_strategy = 'no'
    assert args.max_steps <= 0

    # Match the original trainer's plain TrainingArguments construction path.
    plain_fields = [f.name for f in fields(t.TrainingArguments) if f.init]
    assert 'max_length' not in plain_fields and 'max_seq_length' not in plain_fields
    args = t.TrainingArguments(**{
        name: getattr(args, name) for name in plain_fields if hasattr(args, name)
    })

    out.mkdir(parents=True, exist_ok=False)
    (out / 'run_metadata.json').write_text(json.dumps({
        'run': key, 'epochs': EPOCHS, 'training_records': 1036,
        'base': str(base), 'data': str(root), 'selected_evidence': str(selected),
        'normalization': 'Frozen original 978-record training normalization',
        'training_args': args.to_dict(), 'max_seq_len': seq,
        'warmup_ratio_policy': defaults['warmup_ratio'],
        'input_sha256': run['input_sha256'],
    }, indent=2, default=str))
    print('REFIT_PREFLIGHT_PASS', key, 'records=1036 epochs=7', flush=True)
    print(json.dumps(args.to_dict(), default=str), flush=True)

    t.SEED = run['seed']
    config.MODEL_FALLBACKS = ()  # Fail rather than silently change base model.
    model, tokenizer = t._load_model(str(base), seq)
    model = t.FastLanguageModel.get_peft_model(
        model, r=adapter['r'], target_modules=targets,
        lora_alpha=adapter['lora_alpha'], lora_dropout=adapter['lora_dropout'],
        bias='none', use_gradient_checkpointing='unsloth',
        random_state=run['seed'], use_rslora=False, loftq_config=None,
    )
    t.FastLanguageModel.for_training(model)
    data = t.Dataset.from_list([{'messages': r['messages']} for r in records])
    data = data.map(t._format_dataset, fn_kwargs={'tokenizer': tokenizer},
                    batched=True, remove_columns=data.column_names)
    trainer = t.SFTTrainer(
        model=model, tokenizer=tokenizer, train_dataset=data,
        dataset_text_field='text', max_seq_length=seq, packing=False,
        args=args, callbacks=[],
    )
    # Verify effective preprocessing AFTER the Unsloth/TRL conversion.
    for name, expected in saved_lengths.items():
        actual = getattr(trainer.args, name, None)
        assert actual == expected, ('Effective trainer length changed', name, actual, expected)
    assert trainer.args.num_train_epochs == EPOCHS
    assert not trainer.args.load_best_model_at_end
    assert getattr(trainer.args.eval_strategy, 'value', trainer.args.eval_strategy) == 'no'
    (out / 'effective_trainer_args.json').write_text(
        json.dumps(trainer.args.to_dict(), indent=2, default=str)
    )
    print('EFFECTIVE_TRAINER_MATCH:', saved_lengths, 'epochs=7; evaluation=no', flush=True)
    trainer.train()  # Fresh run: no resume checkpoint or old optimizer/scheduler.
    assert trainer.state.epoch is not None and abs(trainer.state.epoch - EPOCHS) < 0.001
    trainer.save_model(str(model_path))
    tokenizer.save_pretrained(str(model_path))
    trainer.save_state()
    names = ('adapter_config.json', 'adapter_model.safetensors', 'tokenizer_config.json')
    for name in names:
        assert (model_path / name).is_file() and (model_path / name).stat().st_size > 0, name
    (out / 'refit_complete.json').write_text(json.dumps({
        'run': key, 'epochs': EPOCHS, 'training_records': 1036,
        'model_sha256': {name: sha(model_path / name) for name in names},
    }, indent=2))
    print('REFIT_TRAINING_COMPLETE', key, flush=True)
    del trainer, model, tokenizer, data
    gc.collect()
    t.torch.cuda.empty_cache()

if __name__ == '__main__':
    main()
