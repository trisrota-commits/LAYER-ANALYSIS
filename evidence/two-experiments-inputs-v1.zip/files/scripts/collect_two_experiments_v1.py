"""Export a compact, hash-verified analysis bundle. Does not train or modify inputs."""
import argparse
import csv
import hashlib
import json
import zipfile
from pathlib import Path

EPOCH = 'taylor-epoch1-3acc-off-v1'
SEEDS = range(42, 48)

def check(ok, message):
    if not ok:
        raise RuntimeError(message)

def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

def js(p):
    return json.loads(p.read_text())

def host(root, value):
    return root / Path(value).relative_to('/a/mm')

def csv_rows(p):
    with p.open(newline='') as f:
        return list(csv.DictReader(f))

def gather(root):
    files = {}
    def add(path, expected=None):
        path = Path(path)
        relative = path.relative_to(root).as_posix()
        check(path.is_file(), 'Missing required file: '+str(path))
        check(path.stat().st_size < 64*1024*1024, 'Unexpected large artifact: '+str(path))
        check(not any(x.startswith('checkpoint-') for x in path.parts), 'Checkpoint directory selected')
        check(path.suffix not in ('.safetensors','.pt','.pth'), 'Model weights selected')
        digest = sha(path)
        if expected is not None:
            check(digest == expected, 'Hash mismatch: '+relative)
        files[relative] = (path, digest)
    classical = root/'classical-eight-features-v1'
    completed = js(classical/'complete.json')
    check(completed['status']=='complete', 'Classical experiment incomplete')
    add(classical/'complete.json')
    for name,digest in completed['files_sha256'].items():
        add(classical/name,digest)
    classical_contract=js(classical/'contract.json')
    add(root/'run_classical_baselines_v1.py',classical_contract['script_sha256'])
    for rel,digest in classical_contract['input_sha256'].items():
        add(root/rel,digest)

    epoch=root/EPOCH
    prepared=js(epoch/'prepared.json')
    add(epoch/'prepared.json')
    for rel,digest in prepared['files_sha256'].items():
        add(epoch/rel,digest)
    for rel,digest in prepared['dependencies_sha256'].items():
        # Selection training_args.bin are small metadata, not model checkpoints.
        path=root/rel
        if any(x.startswith('checkpoint-') for x in path.parts):
            check(path.name in ('adapter_config.json','training_args.bin','trainer_state.json'), 'Unexpected selection dependency')
            # Historical settings metadata gets a separate archive path below.
            check(path.is_file() and sha(path)==digest,'Selection metadata drift: '+rel)
            check(path.stat().st_size < 2*1024*1024, 'Unexpected selection metadata size')
            archive_name='selection_metadata/'+hashlib.sha256(rel.encode()).hexdigest()[:16]+'/'+path.name
            files[archive_name]=(path,digest)
        else:
            add(path,digest)
    registry=js(epoch/'test_registry.json')
    check(len(registry)==115 and len({r['record_id'] for r in registry})==115,'Bad test registry')
    results=[]
    contracts={}
    for owner in ('zcp-off-toggle-refit7-v1','tables9-12-seeds45-47-v1'):
        path=root/owner/'contract.json'; add(path);contracts[owner]=js(path)
    for seed in SEEDS:
        out=epoch/'results'/f's{seed}'
        done=js(out/'test_complete.json');train=js(out/'refit_complete.json')
        args=js(out/'effective_trainer_args.json');audit=js(out/'runtime_preflight.json')
        key=f'3acc-taylor-epoch1-s{seed}'
        check(done['run']==train['run']==key,'Epoch-1 run identity mismatch')
        check(done['n_samples']==done['n_valid']==115 and done['parse_failures']==0,'Epoch-1 evaluation incomplete')
        check(train['epochs']==7 and train['training_records']==1036,'Epoch-1 refit mismatch')
        check(args['seed']==seed and args['num_train_epochs']==7,'Effective settings mismatch')
        check(audit['run']==key and audit['over_cap_records']==0,'Runtime preflight mismatch')
        for name in ('refit_complete.json','test_complete.json','effective_trainer_args.json','runtime_preflight.json',
                     'run_metadata.json','test_metrics.json','test_metrics.log','test_predictions.csv','per_record_predictions.csv'):
            add(out/name)
        rr=csv_rows(out/'per_record_predictions.csv')
        check([r['record_id'] for r in rr]==[r['record_id'] for r in registry],'Epoch-1 record order mismatch')
        check(all(float(r['target'])==v['target'] and int(r['seed'])==seed for r,v in zip(rr,registry)), 'Epoch-1 target/seed mismatch')
        owner='zcp-off-toggle-refit7-v1' if seed<=44 else 'tables9-12-seeds45-47-v1'
        refkey=f'3acc-no-layer-s{seed}' if seed<=44 else f'3acc-zcp-off-no-layer-s{seed}'
        run=contracts[owner]['runs'][refkey]
        check(run['seed']==seed and run['zero_cost_proxies'] is False,'No-layer condition mismatch')
        for name,digest in run['input_sha256'].items():add(host(root,run['data'])/name,digest)
        refout=host(root,run['output'])
        refdone=js(refout/'test_complete.json')
        check(refdone['run']==refkey and refdone['n_samples']==refdone['n_valid']==115 and refdone['parse_failures']==0,'No-layer reference incomplete')
        for name in ('refit_complete.json','test_complete.json','effective_trainer_args.json','run_metadata.json',
                     'test_metrics.json','test_metrics.log','test_predictions.csv'):
            add(refout/name)
        refrows=csv_rows(refout/'test_predictions.csv')
        check(len(refrows)==115,'No-layer prediction count mismatch')
        for i,(row,item) in enumerate(zip(refrows,registry)):
            check(int(row['idx'])==i and row['dataset']==item['dataset'] and float(row['gt_best_accuracy'])==item['target'], 'No-layer index/dataset/target mismatch')
        results.append(dict(seed=seed,epoch1_output=str(out.relative_to(root)),no_layer_output=str(refout.relative_to(root)),
                            no_layer_contract=owner+'/contract.json',no_layer_run=refkey))
    return files,results

def write_archive(files,results,destination,root):
    check(not destination.exists(), 'Refusing existing export: '+str(destination))
    destination.parent.mkdir(parents=True,exist_ok=True)
    manifest=dict(status='exported',scope='Two experiments plus Taylor epochs1-3 and no-layer/OFF references; no weights or optimizer state',
                  source_root=str(root),runs=results,
                  files={name:dict(sha256=digest,source=str(path),bytes=path.stat().st_size) for name,(path,digest) in files.items()})
    with zipfile.ZipFile(destination,'x',compression=zipfile.ZIP_DEFLATED) as archive:
        for name,(path,digest) in sorted(files.items()):
            content=path.read_bytes()
            check(hashlib.sha256(content).hexdigest()==digest,'File changed while exporting: '+name)
            archive.writestr('files/'+name,content)
        archive.writestr('manifest.json',json.dumps(manifest,indent=2))
    with zipfile.ZipFile(destination) as archive:
        check(archive.testzip() is None,'Archive CRC failed')
        for name,item in manifest['files'].items():
            check(hashlib.sha256(archive.read('files/'+name)).hexdigest()==item['sha256'],'Archive payload hash failed: '+name)
    print('EXPORT VERIFIED:',destination)
    print('FILES:',len(files))
    print('SIZE_MiB:',round(destination.stat().st_size/1024**2,3))
    print('SHA256:',sha(destination))
    print('No training, checkpoint copying, or source modification performed.')

def main():
    p=argparse.ArgumentParser()
    p.add_argument('--root',type=Path,default=Path('/shared/ssd/home/b-t-bose/lmur'))
    a=p.parse_args()
    files,runs=gather(a.root)
    # Include the collector itself under a portable archive name.
    files['scripts/collect_two_experiments_v1.py']=(Path(__file__),sha(Path(__file__)))
    write_archive(files,runs,a.root/'evidence/two-experiments-inputs-v1.zip',a.root)

if __name__=='__main__':
    main()
