# Old-registry audit

Use **verified/** for the completed, checked outputs. `audit_registry.py` is the executed runner and refuses to overwrite that output directory.

## Scope and preservation

Source: `C:/Users/trisr/Downloads/project_final_4_.zip`. Corrected membership comes from frozen thesis evidence using `LAYER-ANALYSIS/analysis/thesis_lemur.py:load_main`. This does not establish the latest Overleaf manuscript state. No training or manuscript changes occurred. The historical project ZIP SHA-256 remained unchanged before/after execution.

## Verified findings

- Missing seeds: ZCP-ON no-layer and all-seven, at both two and three accuracy observations, had only **45,46,47**. Corrected membership is **42,43,44,45,46,47**. Existing predictions were verified unchanged; missing predictions were recovered from frozen evidence.
- Pairing: every consumed registry input matches the same ordered 115 unique identity/dataset pairs and exact targets. Selection uses the same 88 CIFAR-100 records. `verified/source_membership.csv` lists version, condition, seed, exact member path, raw-file SHA-256 and pairing result.
- 18-condition ZCP summary: four contrasts change; OFF wins RMSE in **15/18**, rather than **14/18**, and metric means in **76/90**, rather than **72/90**. These are descriptive counts. Two-accuracy all-seven changes RMSE direction. Full output: `verified/corrected_zcp_18_conditions.csv`.
- Selection: only three-accuracy ZCP-ON **No layer** and **All seven** rows change. `verified/selection_replacement_rows.tex` supplies replacements in the archived `tab:supp-selection` column order. Other reconstructed selection rows are unchanged. Metrics average per-seed rankings, not an ensemble ranking.
- Ensembles: all seven archived summaries already use **42,43,44,45,46,47**, with 115 paired records. Conditions: Taylor/3acc/OFF, no-layer/3acc/OFF, sensitivity/3acc/OFF, Taylor/3acc/ON, Taylor+sensitivity/3acc/OFF, Taylor/2acc/OFF, sensitivity/2acc/OFF. Re-execution reproduces archived JSON within 1e-12. Corrected and historical outputs are identical; no numerical repair is needed. Original bootstrap p-values are reproduced, not claimed as independent mechanism confirmation.
- Four-panel figure: only panel **(b)** changes. Replace the old figure, if still used, with `verified/corrected/images/fig_panels.pdf`. Plotted line/scatter/bar data in (a), (c), (d) are unchanged. The one-page PDF renders all four panels. Existing crowded labels in (a) were retained, not redesigned.

## Boundaries

Panel (a) costs and panel (d) LODO values are hard-coded in the historical script and preserved, not independently re-audited. Panel (c) ranks seed-averaged predictions; the selection table averages per-seed ranking metrics. Historical-reconstruction files are fresh reproductions, not original experiment outputs.

The runner loads archived metric/ranking functions and executes archived ensemble/plot scripts with imports/output paths redirected. Numeric results, explicit ensemble memberships, source hashes, software versions and panel comparisons are in `verified/audit_results.json`.

Earlier artifacts directly in this directory are superseded first-attempt outputs: calculation completed but final JSON serialization failed on a NumPy integer. The issue was fixed and execution completed successfully into fresh `verified/` outputs. Only `verified/` is the deliverable; historical source artifacts were not modified.
