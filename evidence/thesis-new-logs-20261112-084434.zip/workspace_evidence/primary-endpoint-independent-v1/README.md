# Independent primary-endpoint checks

Implementation: `nb201_v1/primary_endpoint.py`; focused tests: `nb201_v1/test_primary_endpoint.py`.

This is an independent implementation of the methods in `.hermes/desktop-attachments/project_final_4_.pdf` (III-D, V-A and collapse AUROC), not the unavailable original `primary_endpoint.py`. Explicit implementation choices and sampling assumptions are recorded in every results.json. No model training was run.

## Authoritative outputs

- `lemur-reference-v2/`: current LEMUR reference verification, from the existing standardized no_layer and qwen_reference seed42–47 prediction CSVs. `lemur-inputs/source_hashes.json` identifies the original source files.
- `cifar10/{ridge,gbm}/` and `cifar100/{ridge,gbm}/`: the completed classical NB201 predictions, analyzed on target >=20% records. These are not Qwen results.
- **Do not use `lemur-reference/` as the final result.** It is preserved diagnostic output from before the mixed-model Hessian validity guard. Its mixed-model p-value was invalid and is superseded by the explicit unverified/null result in v2. No source/prediction data were changed.

## LEMUR reference checks actually reproduced

106 non-collapsed records; MAE improvement 0.4956466541. Paired record t=2.9145256833, p=0.0043543930, CI [0.1584474447,0.8328458635]. Paired seed t=7.7606871782, p=0.0005681849. Holm adjusted p-values: record0.0043543930, seed0.0011363697. These agree with the paper's rounding. Wilcoxon p=0.0111218426 and collapse AUROC also reproduce the rounded reference.

10,000 draws, seed0: record-bootstrap p0.0014; two-way-bootstrap p0.0148; cell sign-flip p0.0001999800. Randomized results need not equal the unavailable original script's draws. Cell-wise flips assume exchangeability despite shared records/seeds and are supporting sensitivity checks, not independent evidence.

**Mixed-model limitation:** the specified difference-scale crossed random-intercept model had non-positive-definite Hessian diagnostics under both L-BFGS and a numerically gated Powell fallback. The final code withholds its p-value and CI. It does not claim to reproduce the manuscript's mixed-model p0.0107. Optimizer selection is based only on numerical validity, never significance. Full attempt diagnostics are saved.

## Classical NB201 interpretation

The seed-labelled predictions are identical within each classical arm. Seed-level t-tests, crossed seed mixed-model inference, and cell-flip p-values are marked not applicable rather than treating duplicates as independent replications. Record-level comparisons, IID bootstrap, family-cluster bootstrap, Wilcoxon, and descriptive/AUROC outputs remain available.

Holm correction is within a declared two-test family per panel, with undefined seed test retained conservatively as p1 for adjustment. It does not control selection across datasets/models; the prior classical Bonferroni8 bootstrap results remain separate and unchanged. The fixed20% threshold follows the supplied protocol, not a universally calibrated failure threshold. NB201 has very few collapsed held-out examples, limiting AUROC conclusions.

## Verification

Six focused tests passed, including exact registry pairing, corruption/missing-row refusal, published LEMUR numbers from actual predictions, invalid-Hessian rejection, Qwen receipt/seed/target checks using disposable fixtures, and output preservation. An OS-safe temporary hermes-verify- script was executed explicitly with exit0; it additionally verified hashes and saved bootstrap endpoints for five actual reports and compared Holm correction with statsmodels. This is ad-hoc verification, not a repository-wide suite or a real NB201 Qwen result.

Local analysis used an isolated `uv run --no-project --with statsmodels --with scikit-learn` environment with the existing Python3.11 interpreter. Hermes's environment was not modified. Versions are saved in reports.

## Qwen status and usage

No NB201 Qwen prediction CSVs were found in the expected local deployment/evidence directories, local nn-gpt, or updated_files_work. A whole-thesis search timed out; this is not proof of global absence. No in-app terminal was available. The user's claimed completed pods need remote output inspection; do not assume they failed or rerun them.

The script can consume the completed cluster bundle directly:

```bash
python primary_endpoint.py --qwen-root /path/to/nb201-v1-qwen-matched-v1 --dataset cifar10 --out /new/analysis/cifar10
```

The paths above illustrate the CLI, not a claim of remote upload. It requires both arms, all six seeds, all test IDs, exact targets, matching prediction hashes, effective seeds, and completion/runtime receipts. It reports all missing required files before creating output. CIFAR100 final-target semantics are checked through run and prediction contracts.

For an existing panel:

```bash
python primary_endpoint.py panel.csv --registry test_registry.json --out new-analysis-directory
```

Default10000draws/seed0/threshold20. `--skip-mixed` is explicit and records the check as unrun. Outputs use exclusive directories, never overwrite predictions or existing reports. Qwen input export lives under output/inputs and analysis under output/analysis; if computation fails after input preparation, preserve inputs and use the panel CLI with those saved files and an absent analysis directory rather than deleting or rerunning training.
