# Dependence heatmap audit — completed against downloaded source

## Inputs
- Archive: article-dependence-source-20261014-150909.tar.gz
- SHA256: 47a7570ef56f874fffa343914b8bbe2d90958b5f67a558e1b5abb1b08411f7ef
- Archive checksum and all 17 manifest payload hashes verified locally.
- Source: files/same_epoch_dependence.csv, September17 with-Places365 analysis.

## Checks performed
- Visually inspected the rendered epoch50 PNG and combined epochs1–3 PNG in graphs-expanded.
- Transcribed displayed values and star presence in their displayed feature/dataset order, then programmatically compared against the authoritative CSV.
- All 168 displayed cells match at three-decimal display precision; all 168 significance indicators match global_bh_fdr_q_value <= 0.05.
- All plotted cells are same-epoch associations (source_epoch equals target_epoch), not early-to-epoch50 associations.
- Recomputed BH correction from all 196 saved analytical p-values, including Places365: maximum difference from stored global q-values = 0.0. Places365 is omitted from the visualization, not removed before recomputing the correction.
- Feature and dataset ordering agree; six displayed datasets exclude Places365.
- Both graphs-expanded PNGs are byte-identical to their corresponding overleaf-integrated/img copies.
- Both archived MIC CSVs are parsed-row identical to the previously checked local graphs-expanded MIC CSVs, whose aggregate table values and BH values matched the article.

## Figure hashes
- layer_dcor_epoch50_heatmap_without_places365.png: 1d5684a29e65e1b024bf41512c520b07f8f839f06d5c25dc5083ecba6ff87e12
- layer_dcor_epochs123_heatmaps_without_places365.png: 29803acc7728c1a4b0c6509bb6389324a69974ae0ee8fd6354c8dfdfc78d837a

## Boundaries
This validates rendered labels/star masks against saved statistical outputs and reproduces BH adjustment. It does not rerun dCor from raw layer observations, prove statistical assumptions, validate every manuscript interpretation, or establish that the current remote Overleaf project contains these exact figure bytes. No original figures, source CSVs, or manuscript files were changed.
