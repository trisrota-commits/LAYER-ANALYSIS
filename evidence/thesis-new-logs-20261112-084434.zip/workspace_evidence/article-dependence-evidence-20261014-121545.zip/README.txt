Dependence evidence package — inspected local files, not a complete scientific certification.
MIC CSV aggregate means, mean absolute Spearman and BH significance counts were checked against the pasted article; see verification.json.
dCor files are CANDIDATE provenance: same_epoch_dependence_fresh.csv does not reproduce the article means (CKA 0.346, rank 0.338, gradient 0.318). It gives CKA 0.341745, rank 0.337244, gradient 0.367231 across available OK cells. Do not silently relabel as article source.
Both local figure copies retained; their identity is not evidence of their generating CSV.
MIC same-epoch Markdown describes max(2,...), whereas its JSON report describes max(4,...); methodological provenance needs reconciliation.
Scripts are current local copies; their identity with historical executed versions is not established.
No analyses rerun. No manuscript/source files edited. Raw run-level feature inputs are not included.
