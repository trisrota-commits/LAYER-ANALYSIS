ImageNet16-120 paired-analysis evidence.
Includes original exported prediction/receipt files, standardized paired inputs, results, saved resamples, and the unchanged CIFAR analysis implementation. No model weights or full pod stdout are included. test_metrics.json files are original evaluator outputs; results.json is the executed statistical analysis, not training stdout.
Primary MAE population: targets >=20 percent; six seeds 42-47; 10000 draws, seed 0. See analysis/results.json for full protocol and mixed-model convergence warnings. Predictions use the registered rounded target; the legacy best_accuracy column does not redefine the fixed-final target.
Source archive SHA256: ebc21e2e41892f2037e0f81be213aa8a682a7191c866e108d6aac5485de5e247
No manuscript files were modified.
