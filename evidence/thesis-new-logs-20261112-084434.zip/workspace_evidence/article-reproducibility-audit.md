# Article reproducibility audit

## Status and scope

**OPEN — evidence/provenance ledger, not a completed reproduction audit.**

Scope: the most recent complete LaTeX manuscript pasted in this conversation, plus subsequently delivered ZCP, readmission, grouped LODO and grouped LOFO tables. Those later tables were delivered in chat; insertion into the authoritative Overleaf source has not been observed.

Evidence boundary: cluster/workstation results and archive checks are operator-executed outputs pasted into chat. Local MIC aggregation and local archive verification were executed by the assistant. No full manuscript compilation, clean-room rerun of this package, or cross-host transfer verification has been performed.

No training reruns, source modifications, or data deletion are authorized by this ledger. Preserve historical outputs and report conflicts rather than choosing a convenient result.

## Evidence locations

- Cluster root: `/shared/ssd/home/b-t-bose/lmur` (abbreviated `CLUSTER/` below).
- Original workstation root: `/home/bose/thesis` (`WORKSTATION/`).
- Windows workspace: `C:\Users\trisr\Desktop\thesis` (`WINDOWS/`).
- Main predictor: frozen snapshot `CLUSTER/out/acc_predict_rebuilt_probe/llm_finetuning_data.jsonl`; grouped split 978/58/115; final refit 1036 records, seven epochs, seeds 42–47 unless explicitly stated otherwise.
- Per-layer variant: 1035 refit records after one authorized training-record exclusion, 115 test, context 16384, microbatch 1 / accumulation 32.
- LODO/LOFO: maximum 20 epochs with validation-loss early stopping patience 3; do not conflate with main final refits.
- Historical: 1082/47/22 split, repeated nominal seed 42. Original versus replay identities require reconciliation.

## Archive inventory and checksums

These hashes were obtained from actual tool/operator output. Source-host checks do not establish successful transfer or package completeness.

| ID | Location | SHA-256 | Verification observed |
|---|---|---|---|
| A | `CLUSTER/evidence/article-tables-only-20261014-111938.tar.gz` | `0dfee5b2e1145d870e56f8a6877d3d2d97832e2be4141f50689f16f3e9b65860` | 1274 copied payloads checked; archive hash later OK on cluster |
| H | `WORKSTATION/evidence/historical-22test-20261014-113613.tar.gz` | `92ae78caeece2f5aa5e3af6c6ff7c789e1a2cb47e71c77676c3e22783ef071ec` | 41 copied payloads checked; archive hash later OK on workstation |
| B | `CLUSTER/evidence/article-timing-baselines-20261014-113919.tar.gz` | `043a264ab8d900bc8a79e337698fb83c773eead4c15cf9399d6eb20e75adb622` | 47 copied and compressed payloads checked; archive hash later OK |
| D | `CLUSTER/evidence/article-dependence-source-20261014-150909.tar.gz` | `47a7570ef56f874fffa343914b8bbe2d90958b5f67a558e1b5abb1b08411f7ef` | 17 copied and compressed payloads checked |
| W | `WINDOWS/evidence/article-dependence-evidence-20261014-121545.zip` | `a16aebbfca4594be252ba0c15b0ef64568b43b52cc653669dddc8f5605053556` | Assistant checked 20 source-file payloads in ZIP and ZIP integrity |

A broader archive `CLUSTER/evidence/taylor-tables-20261014-111149.tar.gz` exists with SHA-256 `44f5c4989c5d1b7b839428fe6e6c88005249cb14bfcb11f5bb0384e26deeeb1f`. It retains prompts, runners and completion files omitted by A, as well as Kubernetes logs. It has a recovery note: original exit statuses of previously exported logs are unavailable. Do not treat A as self-contained merely because the larger archive may contain dependencies.

W includes candidate `_fresh.csv` dCor files that do NOT reproduce the article's bar means. D is the numerically matching dCor source. W's scripts are current local copies, not automatically proven historical executed versions. No archive should be silently overwritten to conceal these distinctions.

## Status vocabulary

- **Recomputed:** reported numerical operation was actually exercised against saved results, within the stated scope.
- **Located:** source/artifact exists, but its full correspondence to the article is not verified.
- **Historical:** prior summary/operator evidence; fresh reproduction still required.
- **Conflict:** observed mismatch requiring resolution.
- **Unpackaged:** output exists in the conversation/terminal but has no verified standalone report/script in the evidence package.

## Table-by-table ledger

Every row below still needs a table-to-file manifest with payload hashes, a saved executable command, environment details and an archive-only reproduction receipt. The 'next check' column identifies the immediate scientific/provenance check, not permission to retrain.

| Article label | Known evidence / generating workflow | Current verification | Next check / gap |
|---|---|---|---|
| `tab:dataset-counts` | Frozen predictor JSONL; task/dataset counts. Source exists on cluster. | Counts appear in supplied manuscript/history; raw snapshot not guaranteed included in compact A. | Count classification records directly from frozen snapshot; retain dataset/task mapping, snapshot hash and script. Do not substitute these counts for dependence complete-case counts. |
| `tab:accpred-metrics-ci` | H; `WORKSTATION/out/acc_predict_rebuilt_probe`, `_layer_run2`, `_layer_run3`; `acc_predict_no_layer_3acc_matched_same42_run{1,3}` and `run2_retry`; two-accuracy no-layer Run 3. | **Conflict/incomplete.** Current layer RMSE logs 8.2038/7.3093/7.0100 average 7.5077, not manuscript 7.4239. Three-accuracy no-layer logs each have 22 valid/zero parse failures. | Recompute all five metrics from CSVs, establish original/replay identities, then recompute nominal-seed repeat intervals. Two-accuracy layer Runs 1–3, no-layer Runs 1–2 and matched input directories missing at inspected paths. Do not invent missing predictions. |
| `tab:main-85-5-10-results` | `table5-refit7-v2/contract.json`; `tables9-12-seeds45-47-v1/run_registry.json`; reused no-layer seed-extension bundle; exact CSV locations from contracts. | Historical six-seed results present in manuscript. A contains many related files, but complete ownership matrix not audited. | Verify all four conditions × six seeds including reused runs, test IDs/targets and effective seeds; recompute means/t CIs. Confirm original main contract and original outputs are actually packaged. |
| `tab:baseline-proxies-85-5-10` | B: `baseline-ci-85510-v1/results/report.json`, `xgboost_report.json`, per-seed prediction/metric files, SynFlow/NASWOT CSV/reports, contract and script. | Located and archive payloads verified; numerical reproduction from archive pending. | Run reporting/calibration verification without refitting; verify training/calibration population, validation selection, seeds and mixed interval definitions. |
| `tab:lodo-2acc-performance` | Historical all-seven/no-layer ZCP-ON LODO batches; not the later Taylor/OFF plan. | Manuscript supplied; exact owning paths/package completeness not established here. | Recover producer registry and all seven dataset folds × two arms × six seeds; retain normalization/split manifests; verify counts and recompute t CIs. |
| `tab:lodo-3acc-performance` | Historical three-accuracy all-seven/no-layer ZCP-ON LODO batches. | Manuscript supplied; not covered automatically by archiving `lodo-taylor-nolayer-off-v1`. | Same ownership audit as two-accuracy LODO; distinguish older 42–44 and extended seed artifacts. |
| `tab:lofo_best_accuracy` | Historical `out/accuracy_predictor_generalization_lofo_v1/lofo_<family>_3acc/{layer,no-layer}-s<seed>`; 42–44, all-seven/ON vs no-layer/ON. | Old means in manuscript. Later grouped bootstrap verifies no-layer test CSV/prompt pairing, not all-seven evidence or old TrainingArguments. | Recover both arms for displayed CNN/detector/segmentation/other folds; verify actual seeds, prompts and metric means. Transformer omission from this particular table is not a missing run. |
| `tab:early-mic` | W: `graphs-expanded/early_to_epoch50_mic_with_places365.csv`; D: `early_to_epoch50_mic.csv`, feature table/report and run-level inputs. | Local W CSV aggregate means, mean absolute Spearman and significant counts match every article row. | Compare D and W CSV hashes/content; verify source epochs 1–3, target epoch 50, complete-case counts and exact BH family. Preserve historical estimator code/environment. |
| `tab:same-epoch-mic` | W same-epoch MIC CSV/table/report; D `same_epoch_mic.csv` and run-level inputs. | Local aggregate means, mean absolute Spearman and significant counts match every article row. | Resolve Markdown `max(2,...)` versus JSON `max(4,...)` description using executed estimator and saved grid-limit column. Verify all 28 cells per feature and BH scope. |
| `tab:layer-statistic-cost-performance` | Three-accuracy ZCP-ON: `layer-ablation-refit7-v1`, `tables9-12-seeds45-47-v1`, plus main/reused baseline contracts. | Historical six-seed table; selected Taylor rows exercised in later paired comparisons. | Reproduce complete nine-condition table, not only Taylor; verify registry includes originals/reused baseline. |
| `tab:layer-features-2acc-zcp-off` | `zcp-off-toggle-refit7-v1` originals and `tables9-12-seeds45-47-v1` extensions. | Historical table; archive presence not complete numeric verification. | Recompute all rows/CIs from six exact seeds and fixed 115 test IDs; verify two accuracy observations plus three layer checkpoints. |
| `tab:layer-features-3acc-zcp-off` | Same original/extension contracts, with reused `taylor-3acc-zcp-off-seeds45-47-v1` runs. | Taylor metrics recomputed during this session; whole table historical. | Verify/recompute remaining features and no-layer/all-seven rows; distinguish layer grad_norm from proxy gradient norm. |
| `tab:layer-features-2acc-zcp-on` | `layer-ablation-2acc-refit7-v1`, main no-layer/all-seven originals and `tables9-12-seeds45-47-v1`. | Manuscript/history only for complete table. | Original two-accuracy single-feature contract was not explicitly included in archive collector; inspect missing dependencies and collect exact sources. |
| `tab:layer-extraction-time` | B: `results/layer_cost_final_100_60min_v1/{candidate_selection.json,dataset_checks.json,timings.csv,timings.jsonl}` and `zcp-five-cost-v1/results/full/{summary.json,timings.jsonl}`; benchmark sources. | Located and archived. Historical reported 96 successful/matched layer cohort, 96 successful ZCP cohort, intersection 93. | Recompute feature-specific/common-cohort means and denominators; retain partial failures; avoid double-counting repeated training-time CSV cells. No extrapolation to total multi-checkpoint cost. |
| `tab:taylor-round2-pairs` | Round2 contracts/CSVs; Taylor OFF original and extension; no-layer OFF originals/extensions. | Pair/Taylor means exercised in paired analysis. | Fresh CSV mean for T+A RMSE prints 8.955724 (4dp 8.9557), whereas manuscript has 8.9558; reconcile precision/source and recompute CIs consistently. Check no-layer provenance separately. |
| `tab:taylor-paired-bootstrap-rmse` | Chat-delivered seven-comparison, five-metric script; exact contracts for Taylor, Round2 and Round3. | **Recomputed:** 36 prediction sets, six seeds, 115 architecture IDs; 35 comparison-metric outputs, 10000 valid draws each. | Save exact successful script and machine-readable output. Retained label says RMSE but caption/table now cover all five. Python random.Random(0), paired records, fitted seeds fixed. |
| `tab:taylor-zcp-on-off` | OFF originals/extensions; ON `layer-ablation-refit7-v1` and `tables9-12-seeds45-47-v1`. | Means/pairing exercised in five-metric bootstrap. | Recompute/package seed-level CIs separately from paired intervals; confirm no duplicate reused seed records. |
| `tab:taylor-readmission-features` | `readmission-3acc-off-v1`, Round2 T+S, original/extended T. | Four specified contrasts recomputed across six seeds. | Preserve descriptive mean/t-CI generator plus exact feature lists; do not infer statistical significance from bold means. |
| `tab:taylor-sensitivity-zcp-on-off` | `round2-taylor-pairs-3acc-off-v1` vs `taylor-sensitivity-zcp-on-v1`. | All five paired comparisons and means recomputed. | Package reports/scripts; existing descriptive table intentionally means-only. |
| `tab:lodo-taylor-zcp-off` | `lodo-taylor-nolayer-off-v1/plan.json`; per-run CSVs/completion/seed metadata, six seeds, three folds. | Coverage/protocol/prompt-target checks and all-five grouped paired calculation passed. | Persist t-CI generator, fold/normalization manifests, grouped-bootstrap script/results and full source hash inventory. |
| `tab:lofo-taylor-zcp-off-comparison` | `lofo-taylor-off-v1` six-seed candidate versus historical no-layer/ON 42–44 baseline. | Six-seed candidate historical report; common-seed baseline/candidate prompts/CSVs checked in later grouped analysis. | Keep unequal-seed descriptive table separate from matched-seed bootstrap. Old baseline actual TrainingArguments were not verified by that reader. |
| `tab:init-taylor-proxy-comparison` | A: `init-taylor-comparison-v1/results-successful-only-v1/{selection.json,report.json,test_predictions.csv}`; original scores/coverage. | Saved CSV/report verification passed; 858 training calibration, 86 successful test candidates; all-five paired intervals. | Include exact subset-analysis command and runtime environment. Failed second exclusive save left added limitation fields and subset complete.json unwritten; selection/README must carry subset limitation. Original 115-test experiment did not complete. |
| `tab:per-layer-versus-averaged-taylor` | Per-layer contracts/CSV/prompt data; historical baseline_predictions.json from checked initialization bundle. | All six per-layer runs verified; 115-record identity/target matched; all-five paired intervals computed. | Save exact read-only script/result and prompt dependencies omitted by A; disclose context/microbatch/exclusion differences. No isolated granularity causal claim. |

## Subsequently delivered tables (insertion not observed)

| Label | Source / verification | Remaining work |
|---|---|---|
| `tab:zcp-paired-five-metrics` | Two ON/OFF comparisons from successful nine-comparison script, six seeds/115 test records; 10000 valid draws per metric. | Save script/results and verify manuscript insertion. Unadjusted, Python RNG seed 0. |
| `tab:readmission-paired-five-metrics` | T+G/T+E vs T and T+S+G/T+S+E vs T+S; all five metrics recomputed. | Save script/results; keep near-zero positive Spearman endpoint +0.000002 for T+S+G vs T+S. |
| `tab:lodo-taylor-record-bootstrap` | Original record-bootstrap table subsequently replaced in chat by **architecture-grouped** table; six seeds. | Confirm grouped replacement actually inserted. Label retained for references; never let old record-level caption survive replacement. Save both variants with explicit names. |
| `tab:lofo-taylor-grouped-bootstrap` | Grouped resampling with common seeds 42–44; no-layer/ON vs Taylor/OFF; five families. | Save exact script/results; original baseline TrainingArguments provenance gap remains. Detector correlations/R2: 9838 finite and 162 invalid draws; other printed cells 10000 valid. |

## Figure-by-figure ledger

| Label / filename | Evidence | Verification / next check |
|---|---|---|
| `fig:mean-layer-dcor` / `mean_dcor_all_datasets_epochs.png` | D CSV and figure; W local copies; `layer-dcor-mean-plot.py`. | Matching September17 CSV yields CKA .346193, rank .337656, gradient .317628, WW .306760, Taylor .299278, sensitivity .287058, activation .187908; 28 valid cells per feature. Displayed article means match. Need hash comparison of final manuscript image and packaged figure, and historical plot-script provenance. |
| `fig:layer-dcor-epoch50` / `layer_dcor_epoch50_heatmap_without_places365.png` | W contains without-Places365 variants; D contains original `layer_dcor_epoch50_heatmap.png` and source CSV. | Exact cell values, star masks, FDR scope, exclusion rule and final figure-byte mapping not yet independently audited. Do not assume differently named originals are identical. |
| `fig:layer-dcor-epochs123` / `layer_dcor_epochs123_heatmaps_without_places365.png` | W without-Places365 combined heatmap; D originals/CSV; plot script. | Verify same-epoch (not early-to-50) input, all displayed cells and significance masks, excluded dataset and final figure hash. |
| `fig:layer-cost-pareto` / inline PGFPlots | Coordinates in pasted manuscript, six-seed ON prediction means and B timing results. Local `paper_figures/layer_cost_pareto/pareto_data.csv` also exists but its match is not established. | Recompute mean-based nondominance from exact plotted coordinates; check all coordinates against tables; no uncertainty-aware Pareto claim. Different timing/prediction cohorts must remain explicit. |

No MIC plot is required by this manuscript: MIC appears as two tables. Do not generate extra plots merely for archival completeness.

## Known scientific and manuscript conflicts

1. Historical 22-test layer mean: archived logs average RMSE 7.5077, article says 7.4239. Trace original trial identity, not just folder name. Missing original evidence must remain disclosed.
2. Abstract still emphasizes old small-test values and old train-plus-test runtimes; current expanded experiments have different rankings/protocols.
3. Main table prose contains stale three-seed numbers (8.9910/12.5177, 9.4360/11.9404); XGBoost prose also differs from the displayed six-seed table.
4. Methods mix historical 1082/47/22, alternate 50/30/20, main grouped85/5/10, nominal same-seed repeats and independent seeds42–47. Preserve each experiment's actual protocol.
5. 'Two accuracies ... model trained for two epochs but receives three snapshots' is not a valid candidate-training-budget description. Two visible accuracies still use epoch3 layer inputs.
6. Nominal context6144 versus historical actual trainer max_length1024 must be reported from saved effective settings; new per-layer16384 is distinct.
7. dCor equation in pasted manuscript lacks the inner square root in normalization: with Dxy=dCov²(X,Y), Dxx=dCov²(X,X), Dyy=dCov²(Y,Y), dCor = sqrt(Dxy / sqrt(Dxx*Dyy)). A manuscript equation issue does not imply package-generated results were computed incorrectly.
8. MIC same-epoch Markdown grid-limit minimum2 versus JSON minimum4 needs source reconciliation; table aggregate agreement does not resolve estimator provenance.
9. Inferential intervals are conditional on fitted models/seeds and unadjusted for multiplicity/prior test-set feature selection. Do not call inconclusive contrasts equivalent or treat feature selection as confirmatory.
10. Paired grouped LOFO uses42–44, while descriptive Taylor LOFO uses42–47. Do not substitute one mean for another silently.
11. Mid-document usepackage and missing holdoutci definition in pasted source prevent a clean compile; final Overleaf copy may differ and must be inspected.
12. Venue/fee assertions and bibliography entries have not been independently verified in this audit. Placeholder Second Author remains in supplied author list.

## Required per-item reproduction record

For each table/figure, create one record with:

- article label and exact manuscript revision/hash;
- estimand: target, horizon, feature subset, ZCP toggle, fitting cohort, split/fold, seed set;
- exact input paths and hashes, including prompts/splits/normalization where necessary;
- exact historical executed source or explicit current-reimplementation label;
- command and environment: Python/dependency versions, model revision, image digest/hardware for training/extraction;
- generated output path/hash, numeric tolerances and invalid-case handling;
- comparison to manuscript values (pass/conflict/pending);
- disclosed missing files and scope limits.

Do not load untrusted pickle/training_args.bin artifacts merely to enumerate files; use the trusted producing environment when authorized.

## Next bounded actions

1. **Inventory existing archives against this ledger**, without broad Kubernetes log exports: especially original main runs, two-accuracy ON originals, all-seven/no-layer LODO sources, prompt/split/normalization dependencies and analysis scripts. Paths in contracts alone are not packaged files.
2. **Persist exact successful bootstrap scripts and outputs** from the conversation. If reconstructing an output from pasted numbers, label it a transcription, not a fresh execution. Prefer re-executing only cheap saved-prediction analyses with stdout/JSON/CSV capture, preserving original experiments and RNG choices.
3. **Resolve the historical 22-record conflict** and document missing originals. Do not retrain to manufacture a historical match. Choose correction/qualification/removal only with author approval.
4. **Link dependence figures and final manuscript source** to exact data/script hashes; reconcile MIC estimator description and manuscript dCor equation.
5. **Run an archive-only reproduction check** for every retained table/figure. This should not depend on original absolute cluster paths; retain both original paths and relocatable reproduction mapping.
6. **Transfer and independently verify backups**, including compressed payload checks against manifests, then compile the final manuscript and reconcile every retained numerical claim.

## Completion criteria

A checksum-complete archive is not the same as a reproducible article. Mark the audit complete only when every retained label has a verified source mapping and an exercised reproduction command, or a clear limitation accepted by the authors. Separate reproducing tables from saved predictions from reproducing GPU training/extraction from scratch; the latter additionally needs model/data access, exact source/environment and nondeterminism disclosures.
