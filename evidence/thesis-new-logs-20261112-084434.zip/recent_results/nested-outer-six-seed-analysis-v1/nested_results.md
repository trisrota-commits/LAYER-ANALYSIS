# Nested outer results: seeds42-47

Seeds42-47;1139 classification records per condition and seed; all target accuracies.
Architecture groups per fold: [212, 215, 212]; classification records per fold: [380, 381, 378].
Metrics are pooled across outer folds within each seed, then averaged across seeds. Predictions are not ensembled.
Paired bootstrap:10000 architecture-group resamples stratified within each original outer fold. The same resample is used for both conditions and every seed.
The original number of groups is sampled with replacement per fold; all records in a sampled group are retained, including repeated groups.
Bonferroni5 corrects the five Taylor-versus-no-layer metric comparisons. Positive differences always favor Taylor.
Inference conditions on the observed folds, fitted models and inner selections; it does not repeat the nested training/search procedure or resample predictor seeds.
Selected-procedure values are descriptive and follow each fold's locked inner feature choice; they are not an ensemble or an outer-test-selected model.

## Mean metrics

| Method | RMSE | MAE | Pearson | Spearman | R2 |
|---|---:|---:|---:|---:|---:|
| no-layer | 12.624609 | 7.075366 | 0.897926 | 0.902578 | 0.780074 |
| taylor | 12.368523 | 6.811462 | 0.902668 | 0.909482 | 0.789134 |
| selected-procedure | 12.446581 | 6.909594 | 0.901801 | 0.908180 | 0.786660 |

## Paired bootstrap

| Metric | Improvement | 95% CI | Bonferroni5 CI | Seeds favoring Taylor |
|---|---:|---|---|---:|
| RMSE | +0.256085 | [-0.396108, 0.936377] | [-0.592499, 1.166064] | 4/6 |
| MAE | +0.263904 | [0.018639, 0.524492] | [-0.056045, 0.605292] | 6/6 |
| Pearson | +0.004742 | [-0.006309, 0.016234] | [-0.009797, 0.020145] | 4/6 |
| Spearman | +0.006904 | [-0.003117, 0.017484] | [-0.006367, 0.021174] | 4/6 |
| R2 | +0.009060 | [-0.013829, 0.032308] | [-0.020942, 0.040052] | 4/6 |

## Per-seed metrics

| Seed | Method | RMSE | MAE | Pearson | Spearman | R2 |
|---|---|---:|---:|---:|---:|---:|
| 42 | no-layer | 12.065851 | 6.910132 | 0.913309 | 0.918135 | 0.799604 |
| 42 | taylor | 12.172551 | 6.778955 | 0.907622 | 0.915569 | 0.796044 |
| 42 | selected-procedure | 12.283984 | 6.855549 | 0.905961 | 0.913533 | 0.792293 |
| 43 | no-layer | 13.932383 | 7.396699 | 0.871684 | 0.868206 | 0.732807 |
| 43 | taylor | 12.834784 | 6.954996 | 0.895451 | 0.899997 | 0.773248 |
| 43 | selected-procedure | 12.834784 | 6.954996 | 0.895451 | 0.899997 | 0.773248 |
| 44 | no-layer | 12.305815 | 7.011624 | 0.905406 | 0.911005 | 0.791554 |
| 44 | taylor | 12.086410 | 6.769596 | 0.909482 | 0.916711 | 0.798920 |
| 44 | selected-procedure | 12.305815 | 7.011624 | 0.905406 | 0.911005 | 0.791554 |
| 45 | no-layer | 12.646506 | 7.120070 | 0.894333 | 0.903782 | 0.779852 |
| 45 | taylor | 12.369918 | 6.793300 | 0.902438 | 0.910577 | 0.789376 |
| 45 | selected-procedure | 12.620010 | 6.959823 | 0.899007 | 0.906665 | 0.780774 |
| 46 | no-layer | 12.647663 | 7.180571 | 0.898789 | 0.905624 | 0.779812 |
| 46 | taylor | 13.054119 | 6.945268 | 0.890219 | 0.899285 | 0.765432 |
| 46 | selected-procedure | 12.606090 | 6.876611 | 0.899910 | 0.908825 | 0.781257 |
| 47 | no-layer | 12.149434 | 6.833099 | 0.904035 | 0.908714 | 0.796818 |
| 47 | taylor | 11.693357 | 6.626655 | 0.910798 | 0.914751 | 0.811786 |
| 47 | selected-procedure | 12.028802 | 6.798962 | 0.905069 | 0.909055 | 0.800833 |
