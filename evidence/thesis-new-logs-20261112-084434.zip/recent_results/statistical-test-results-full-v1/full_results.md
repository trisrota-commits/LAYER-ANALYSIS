# Full recent paired-test results

- Scope: all 167 metric-level intervals from the four recent paired-analysis families discussed in this chat. This is not an inventory of every historical test in the thesis.
- Positive improvement always favors the candidate named after the arrow. Error metrics: reference minus candidate; correlations and R2: candidate minus reference.
- Every bootstrap uses 10000 draws and seed 0, with fitted predictors held fixed. Predictor-seed uncertainty is not resampled.
- NB201 Qwen and HistGB use operation-family resampling, preserving every record in each sampled group. LEMUR comparisons resample paired test records.
- Correction families are separate: NB201 Qwen Bonferroni12; HistGB Bonferroni40 within each dataset; LEMUR extra contrasts Bonferroni20; Qwen/classical Bonferroni15. There is no claimed joint correction across all 167 rows.
- HistGB all and target_ge20 populations are both included. ImageNet16-120 HistGB uses a partial cohort; the Qwen study uses all 275 test records per dataset.
- All HistGB seed-labelled prediction vectors were identical within each arm. This is not six independent confirmations of fitting variability.
- LEMUR XGBoost and proxy predictions are rescored against the same two-decimal targets as Qwen. Minor last-digit differences from old full-precision descriptive tables are expected.
- The SynFlow/NASWOT comparisons contrast complete approaches with unequal information budgets. They do not isolate Taylor or measurement time.
- These extensions are post-hoc supporting analyses. Corrections do not remove earlier feature-selection bias. Percentile intervals are approximate, and the most extreme adjusted quantiles use relatively few tail draws.
- Not newly computed here: original primary Holm-adjusted MAE tests, older ablations/holdouts, paired Taylor effects within classical LEMUR models, or nested outer results for seeds43-47.

## HistGB four-arm study | CIFAR-10-valid | all
A_LC -> A_LC_T

n=275; groups=46; Bonferroni40 within dataset

| Metric | Reference | Candidate | Improvement | Unadjusted 95% CI | Adjusted CI | Adjusted result |
|---|---:|---:|---:|---|---|---|
| RMSE | 2.927496 | 2.351435 | +0.576061 | [-0.003783, 1.229083] | [-0.244857, 1.677820] | Inconclusive |
| MAE | 1.615035 | 1.424065 | +0.190970 | [-0.003694, 0.430221] | [-0.116142, 0.634279] | Inconclusive |
| Pearson | 0.942046 | 0.962553 | +0.020507 | [-0.000091, 0.079722] | [-0.009613, 0.166937] | Inconclusive |
| Spearman | 0.791055 | 0.822590 | +0.031535 | [-0.025056, 0.086165] | [-0.055922, 0.123327] | Inconclusive |
| R2 | 0.884878 | 0.925727 | +0.040849 | [-0.000233, 0.173385] | [-0.018620, 0.438778] | Inconclusive |

## HistGB four-arm study | CIFAR-10-valid | all
A -> A_LC

n=275; groups=46; Bonferroni40 within dataset

| Metric | Reference | Candidate | Improvement | Unadjusted 95% CI | Adjusted CI | Adjusted result |
|---|---:|---:|---:|---|---|---|
| RMSE | 4.765310 | 2.927496 | +1.837814 | [0.976911, 2.804417] | [0.599006, 3.464425] | Favors candidate |
| MAE | 2.953093 | 1.615035 | +1.338059 | [0.953629, 1.849226] | [0.737854, 2.214286] | Favors candidate |
| Pearson | 0.841285 | 0.942046 | +0.100761 | [0.037472, 0.292676] | [0.020409, 0.392526] | Favors candidate |
| Spearman | 0.435498 | 0.791055 | +0.355557 | [0.266631, 0.441015] | [0.213837, 0.502852] | Favors candidate |
| R2 | 0.694965 | 0.884878 | +0.189912 | [0.073172, 0.591116] | [0.040817, 1.195597] | Favors candidate |

## HistGB four-arm study | CIFAR-10-valid | all
A -> A_T

n=275; groups=46; Bonferroni40 within dataset

| Metric | Reference | Candidate | Improvement | Unadjusted 95% CI | Adjusted CI | Adjusted result |
|---|---:|---:|---:|---|---|---|
| RMSE | 4.765310 | 3.638733 | +1.126576 | [0.745980, 1.549142] | [0.513232, 1.816657] | Favors candidate |
| MAE | 2.953093 | 1.947351 | +1.005743 | [0.664617, 1.411873] | [0.470236, 1.734587] | Favors candidate |
| Pearson | 0.841285 | 0.909768 | +0.068483 | [0.028551, 0.215146] | [0.015630, 0.303284] | Favors candidate |
| Spearman | 0.435498 | 0.697457 | +0.261959 | [0.148068, 0.361452] | [0.075806, 0.422500] | Favors candidate |
| R2 | 0.694965 | 0.822144 | +0.127179 | [0.055101, 0.424018] | [0.030200, 0.842356] | Favors candidate |

## HistGB four-arm study | CIFAR-10-valid | all
A_T -> A_LC_T

n=275; groups=46; Bonferroni40 within dataset

| Metric | Reference | Candidate | Improvement | Unadjusted 95% CI | Adjusted CI | Adjusted result |
|---|---:|---:|---:|---|---|---|
| RMSE | 3.638733 | 2.351435 | +1.287298 | [0.318528, 2.418036] | [0.053226, 3.243960] | Favors candidate |
| MAE | 1.947351 | 1.424065 | +0.523286 | [0.260251, 0.888710] | [0.134427, 1.167010] | Favors candidate |
| Pearson | 0.909768 | 0.962553 | +0.052786 | [0.009139, 0.165779] | [-0.000466, 0.270503] | Inconclusive |
| Spearman | 0.697457 | 0.822590 | +0.125133 | [0.066314, 0.204359] | [0.032403, 0.271263] | Favors candidate |
| R2 | 0.822144 | 0.925727 | +0.103582 | [0.019943, 0.351800] | [0.003602, 0.741763] | Favors candidate |

## HistGB four-arm study | CIFAR-10-valid | target_ge20
A_LC -> A_LC_T

n=273; groups=45; Bonferroni40 within dataset

| Metric | Reference | Candidate | Improvement | Unadjusted 95% CI | Adjusted CI | Adjusted result |
|---|---:|---:|---:|---|---|---|
| RMSE | 2.938198 | 2.359963 | +0.578236 | [-0.004918, 1.235165] | [-0.258538, 1.709145] | Inconclusive |
| MAE | 1.626634 | 1.432956 | +0.193678 | [-0.002992, 0.436472] | [-0.130513, 0.616308] | Inconclusive |
| Pearson | 0.865542 | 0.912804 | +0.047262 | [-0.000493, 0.129391] | [-0.022401, 0.202283] | Inconclusive |
| Spearman | 0.786429 | 0.818663 | +0.032234 | [-0.026134, 0.087529] | [-0.060729, 0.124170] | Inconclusive |
| R2 | 0.738643 | 0.831390 | +0.092748 | [-0.000683, 0.314325] | [-0.046478, 0.593753] | Inconclusive |

## HistGB four-arm study | CIFAR-10-valid | target_ge20
A -> A_LC

n=273; groups=45; Bonferroni40 within dataset

| Metric | Reference | Candidate | Improvement | Unadjusted 95% CI | Adjusted CI | Adjusted result |
|---|---:|---:|---:|---|---|---|
| RMSE | 4.782725 | 2.938198 | +1.844526 | [0.969848, 2.820611] | [0.590368, 3.453250] | Favors candidate |
| MAE | 2.973980 | 1.626634 | +1.347346 | [0.959765, 1.854887] | [0.737732, 2.175364] | Favors candidate |
| Pearson | 0.617891 | 0.865542 | +0.247651 | [0.133507, 0.362389] | [0.078984, 0.425613] | Favors candidate |
| Spearman | 0.423000 | 0.786429 | +0.363429 | [0.273413, 0.454412] | [0.229087, 0.530022] | Favors candidate |
| R2 | 0.307494 | 0.738643 | +0.431148 | [0.237297, 0.922161] | [0.145758, 1.579573] | Favors candidate |

## HistGB four-arm study | CIFAR-10-valid | target_ge20
A -> A_T

n=273; groups=45; Bonferroni40 within dataset

| Metric | Reference | Candidate | Improvement | Unadjusted 95% CI | Adjusted CI | Adjusted result |
|---|---:|---:|---:|---|---|---|
| RMSE | 4.782725 | 3.652022 | +1.130703 | [0.749093, 1.557554] | [0.512213, 1.862301] | Favors candidate |
| MAE | 2.973980 | 1.960717 | +1.013263 | [0.670954, 1.423635] | [0.483561, 1.716899] | Favors candidate |
| Pearson | 0.617891 | 0.789963 | +0.172072 | [0.086866, 0.290553] | [0.055320, 0.349089] | Favors candidate |
| Spearman | 0.423000 | 0.690759 | +0.267759 | [0.146652, 0.370895] | [0.080371, 0.431610] | Favors candidate |
| R2 | 0.307494 | 0.596225 | +0.288731 | [0.143532, 0.663300] | [0.098517, 1.050551] | Favors candidate |

## HistGB four-arm study | CIFAR-10-valid | target_ge20
A_T -> A_LC_T

n=273; groups=45; Bonferroni40 within dataset

| Metric | Reference | Candidate | Improvement | Unadjusted 95% CI | Adjusted CI | Adjusted result |
|---|---:|---:|---:|---|---|---|
| RMSE | 3.652022 | 2.359963 | +1.292059 | [0.306462, 2.412654] | [0.049042, 3.231399] | Favors candidate |
| MAE | 1.960717 | 1.432956 | +0.527761 | [0.258902, 0.886296] | [0.132356, 1.123638] | Favors candidate |
| Pearson | 0.789963 | 0.912804 | +0.122841 | [0.022454, 0.228229] | [-0.006592, 0.316005] | Inconclusive |
| Spearman | 0.690759 | 0.818663 | +0.127904 | [0.068075, 0.208747] | [0.041392, 0.272533] | Favors candidate |
| R2 | 0.596225 | 0.831390 | +0.235165 | [0.063674, 0.566312] | [0.008926, 1.100451] | Favors candidate |

## HistGB four-arm study | CIFAR-100 | all
A_LC -> A_LC_T

n=275; groups=46; Bonferroni40 within dataset

| Metric | Reference | Candidate | Improvement | Unadjusted 95% CI | Adjusted CI | Adjusted result |
|---|---:|---:|---:|---|---|---|
| RMSE | 4.816514 | 4.240512 | +0.576002 | [-0.000907, 1.161800] | [-0.309627, 1.611242] | Inconclusive |
| MAE | 2.349325 | 2.094311 | +0.255014 | [-0.006681, 0.523133] | [-0.134881, 0.711332] | Inconclusive |
| Pearson | 0.859582 | 0.890878 | +0.031295 | [-0.001391, 0.083014] | [-0.016942, 0.135019] | Inconclusive |
| Spearman | 0.847074 | 0.904782 | +0.057708 | [0.007628, 0.106253] | [-0.014383, 0.140242] | Inconclusive |
| R2 | 0.731296 | 0.791721 | +0.060425 | [-0.000075, 0.158536] | [-0.024253, 0.242162] | Inconclusive |

## HistGB four-arm study | CIFAR-100 | all
A -> A_LC

n=275; groups=46; Bonferroni40 within dataset

| Metric | Reference | Candidate | Improvement | Unadjusted 95% CI | Adjusted CI | Adjusted result |
|---|---:|---:|---:|---|---|---|
| RMSE | 5.484181 | 4.816514 | +0.667666 | [-0.366476, 1.742785] | [-1.050754, 2.290332] | Inconclusive |
| MAE | 3.515785 | 2.349325 | +1.166461 | [0.811830, 1.603793] | [0.615194, 1.897746] | Favors candidate |
| Pearson | 0.809427 | 0.859582 | +0.050156 | [-0.000295, 0.135634] | [-0.028384, 0.239777] | Inconclusive |
| Spearman | 0.644182 | 0.847074 | +0.202892 | [0.113299, 0.301511] | [0.068244, 0.378192] | Favors candidate |
| R2 | 0.651637 | 0.731296 | +0.079659 | [-0.055027, 0.221180] | [-0.217882, 0.401718] | Inconclusive |

## HistGB four-arm study | CIFAR-100 | all
A -> A_T

n=275; groups=46; Bonferroni40 within dataset

| Metric | Reference | Candidate | Improvement | Unadjusted 95% CI | Adjusted CI | Adjusted result |
|---|---:|---:|---:|---|---|---|
| RMSE | 5.484181 | 4.121713 | +1.362468 | [0.695618, 2.069409] | [0.300261, 2.705946] | Favors candidate |
| MAE | 3.515785 | 2.419289 | +1.096496 | [0.709645, 1.534676] | [0.497009, 1.871497] | Favors candidate |
| Pearson | 0.809427 | 0.896653 | +0.087227 | [0.034156, 0.187198] | [0.012520, 0.291437] | Favors candidate |
| Spearman | 0.644182 | 0.848389 | +0.204207 | [0.117768, 0.286426] | [0.075530, 0.351435] | Favors candidate |
| R2 | 0.651637 | 0.803228 | +0.151591 | [0.064104, 0.303383] | [0.024719, 0.437015] | Favors candidate |

## HistGB four-arm study | CIFAR-100 | all
A_T -> A_LC_T

n=275; groups=46; Bonferroni40 within dataset

| Metric | Reference | Candidate | Improvement | Unadjusted 95% CI | Adjusted CI | Adjusted result |
|---|---:|---:|---:|---|---|---|
| RMSE | 4.121713 | 4.240512 | -0.118800 | [-1.040059, 0.774652] | [-1.747992, 1.107959] | Inconclusive |
| MAE | 2.419289 | 2.094311 | +0.324979 | [0.061657, 0.563869] | [-0.134990, 0.703805] | Inconclusive |
| Pearson | 0.896653 | 0.890878 | -0.005775 | [-0.056742, 0.040001] | [-0.094425, 0.077196] | Inconclusive |
| Spearman | 0.848389 | 0.904782 | +0.056393 | [0.023567, 0.097392] | [0.004354, 0.128585] | Favors candidate |
| R2 | 0.803228 | 0.791721 | -0.011507 | [-0.143097, 0.075050] | [-0.343140, 0.140331] | Inconclusive |

## HistGB four-arm study | CIFAR-100 | target_ge20
A_LC -> A_LC_T

n=272; groups=44; Bonferroni40 within dataset

| Metric | Reference | Candidate | Improvement | Unadjusted 95% CI | Adjusted CI | Adjusted result |
|---|---:|---:|---:|---|---|---|
| RMSE | 4.622749 | 4.010532 | +0.612217 | [0.001540, 1.233001] | [-0.388216, 1.708253] | Inconclusive |
| MAE | 2.282973 | 2.024569 | +0.258403 | [-0.001106, 0.529971] | [-0.150290, 0.690079] | Inconclusive |
| Pearson | 0.775583 | 0.829089 | +0.053506 | [-0.005884, 0.125702] | [-0.033727, 0.189955] | Inconclusive |
| Spearman | 0.841998 | 0.901637 | +0.059639 | [0.009710, 0.108725] | [-0.014404, 0.147481] | Inconclusive |
| R2 | 0.560549 | 0.669239 | +0.108690 | [0.000204, 0.237123] | [-0.053785, 0.342375] | Inconclusive |

## HistGB four-arm study | CIFAR-100 | target_ge20
A -> A_LC

n=272; groups=44; Bonferroni40 within dataset

| Metric | Reference | Candidate | Improvement | Unadjusted 95% CI | Adjusted CI | Adjusted result |
|---|---:|---:|---:|---|---|---|
| RMSE | 5.240618 | 4.622749 | +0.617869 | [-0.449810, 1.784709] | [-1.146445, 2.444328] | Inconclusive |
| MAE | 3.448538 | 2.282973 | +1.165565 | [0.811354, 1.609456] | [0.597627, 2.002562] | Favors candidate |
| Pearson | 0.681653 | 0.775583 | +0.093931 | [0.016175, 0.207404] | [-0.025675, 0.296767] | Inconclusive |
| Spearman | 0.632332 | 0.841998 | +0.209666 | [0.117695, 0.311488] | [0.071717, 0.392575] | Favors candidate |
| R2 | 0.435226 | 0.560549 | +0.125323 | [-0.117026, 0.331862] | [-0.358944, 0.461286] | Inconclusive |

## HistGB four-arm study | CIFAR-100 | target_ge20
A -> A_T

n=272; groups=44; Bonferroni40 within dataset

| Metric | Reference | Candidate | Improvement | Unadjusted 95% CI | Adjusted CI | Adjusted result |
|---|---:|---:|---:|---|---|---|
| RMSE | 5.240618 | 3.904197 | +1.336421 | [0.640492, 2.093587] | [0.236710, 2.653705] | Favors candidate |
| MAE | 3.448538 | 2.359833 | +1.088704 | [0.699274, 1.525815] | [0.475558, 1.830963] | Favors candidate |
| Pearson | 0.681653 | 0.834665 | +0.153012 | [0.062514, 0.271974] | [0.017771, 0.367827] | Favors candidate |
| Spearman | 0.632332 | 0.843318 | +0.210986 | [0.123573, 0.297814] | [0.075501, 0.371945] | Favors candidate |
| R2 | 0.435226 | 0.686546 | +0.251321 | [0.114322, 0.419295] | [0.036106, 0.510182] | Favors candidate |

## HistGB four-arm study | CIFAR-100 | target_ge20
A_T -> A_LC_T

n=272; groups=44; Bonferroni40 within dataset

| Metric | Reference | Candidate | Improvement | Unadjusted 95% CI | Adjusted CI | Adjusted result |
|---|---:|---:|---:|---|---|---|
| RMSE | 3.904197 | 4.010532 | -0.106336 | [-1.064826, 0.865258] | [-1.707929, 1.255865] | Inconclusive |
| MAE | 2.359833 | 2.024569 | +0.335264 | [0.067333, 0.577710] | [-0.083344, 0.745649] | Inconclusive |
| Pearson | 0.834665 | 0.829089 | -0.005575 | [-0.072045, 0.066481] | [-0.105841, 0.112192] | Inconclusive |
| Spearman | 0.843318 | 0.901637 | +0.058319 | [0.025613, 0.101671] | [0.005428, 0.134848] | Favors candidate |
| R2 | 0.686546 | 0.669239 | -0.017307 | [-0.239636, 0.125077] | [-0.477413, 0.195703] | Inconclusive |

## HistGB four-arm study | ImageNet16-120 (partial) | all
A_LC -> A_LC_T

n=198; groups=43; Bonferroni40 within dataset

| Metric | Reference | Candidate | Improvement | Unadjusted 95% CI | Adjusted CI | Adjusted result |
|---|---:|---:|---:|---|---|---|
| RMSE | 2.427732 | 2.296356 | +0.131376 | [-0.009312, 0.317820] | [-0.080586, 0.471439] | Inconclusive |
| MAE | 1.568959 | 1.595706 | -0.026747 | [-0.136922, 0.117761] | [-0.199618, 0.226457] | Inconclusive |
| Pearson | 0.945626 | 0.951320 | +0.005694 | [-0.000566, 0.014323] | [-0.004003, 0.022625] | Inconclusive |
| Spearman | 0.920684 | 0.927709 | +0.007025 | [-0.006182, 0.018118] | [-0.016727, 0.031278] | Inconclusive |
| R2 | 0.891755 | 0.903153 | +0.011398 | [-0.000897, 0.028888] | [-0.008826, 0.044980] | Inconclusive |

## HistGB four-arm study | ImageNet16-120 (partial) | all
A -> A_LC

n=198; groups=43; Bonferroni40 within dataset

| Metric | Reference | Candidate | Improvement | Unadjusted 95% CI | Adjusted CI | Adjusted result |
|---|---:|---:|---:|---|---|---|
| RMSE | 5.345812 | 2.427732 | +2.918080 | [2.100415, 3.733513] | [1.398556, 4.255457] | Favors candidate |
| MAE | 3.771723 | 1.568959 | +2.202764 | [1.655184, 2.820345] | [1.303386, 3.245531] | Favors candidate |
| Pearson | 0.722836 | 0.945626 | +0.222790 | [0.127107, 0.348551] | [0.084273, 0.456285] | Favors candidate |
| Spearman | 0.581390 | 0.920684 | +0.339294 | [0.202008, 0.475550] | [0.124191, 0.567244] | Favors candidate |
| R2 | 0.475150 | 0.891755 | +0.416604 | [0.249620, 0.667448] | [0.162742, 0.876824] | Favors candidate |

## HistGB four-arm study | ImageNet16-120 (partial) | all
A -> A_T

n=198; groups=43; Bonferroni40 within dataset

| Metric | Reference | Candidate | Improvement | Unadjusted 95% CI | Adjusted CI | Adjusted result |
|---|---:|---:|---:|---|---|---|
| RMSE | 5.345812 | 3.900289 | +1.445522 | [0.739919, 2.230778] | [0.246032, 2.824949] | Favors candidate |
| MAE | 3.771723 | 2.744397 | +1.027326 | [0.556839, 1.629417] | [0.264128, 2.104504] | Favors candidate |
| Pearson | 0.722836 | 0.850606 | +0.127770 | [0.052277, 0.231537] | [0.015270, 0.316423] | Favors candidate |
| Spearman | 0.581390 | 0.776719 | +0.195329 | [0.098895, 0.304747] | [0.055634, 0.384787] | Favors candidate |
| R2 | 0.475150 | 0.720616 | +0.245466 | [0.110130, 0.444443] | [0.032149, 0.643005] | Favors candidate |

## HistGB four-arm study | ImageNet16-120 (partial) | all
A_T -> A_LC_T

n=198; groups=43; Bonferroni40 within dataset

| Metric | Reference | Candidate | Improvement | Unadjusted 95% CI | Adjusted CI | Adjusted result |
|---|---:|---:|---:|---|---|---|
| RMSE | 3.900289 | 2.296356 | +1.603933 | [1.154124, 2.035525] | [0.859425, 2.428428] | Favors candidate |
| MAE | 2.744397 | 1.595706 | +1.148692 | [0.760855, 1.520663] | [0.579999, 1.727490] | Favors candidate |
| Pearson | 0.850606 | 0.951320 | +0.100714 | [0.057790, 0.153061] | [0.038202, 0.193528] | Favors candidate |
| Spearman | 0.776719 | 0.927709 | +0.150990 | [0.071604, 0.232670] | [0.037964, 0.287874] | Favors candidate |
| R2 | 0.720616 | 0.903153 | +0.182537 | [0.111289, 0.281002] | [0.073649, 0.361665] | Favors candidate |

## HistGB four-arm study | ImageNet16-120 (partial) | target_ge20
A_LC -> A_LC_T

n=187; groups=41; Bonferroni40 within dataset

| Metric | Reference | Candidate | Improvement | Unadjusted 95% CI | Adjusted CI | Adjusted result |
|---|---:|---:|---:|---|---|---|
| RMSE | 2.438814 | 2.310350 | +0.128465 | [-0.005838, 0.316589] | [-0.073189, 0.467538] | Inconclusive |
| MAE | 1.567286 | 1.600975 | -0.033689 | [-0.138308, 0.105546] | [-0.191335, 0.202713] | Inconclusive |
| Pearson | 0.910495 | 0.919831 | +0.009337 | [-0.000274, 0.022722] | [-0.005117, 0.036278] | Inconclusive |
| Spearman | 0.906317 | 0.914640 | +0.008322 | [-0.006768, 0.021858] | [-0.018650, 0.037392] | Inconclusive |
| R2 | 0.818487 | 0.837106 | +0.018619 | [-0.000948, 0.044534] | [-0.013316, 0.069561] | Inconclusive |

## HistGB four-arm study | ImageNet16-120 (partial) | target_ge20
A -> A_LC

n=187; groups=41; Bonferroni40 within dataset

| Metric | Reference | Candidate | Improvement | Unadjusted 95% CI | Adjusted CI | Adjusted result |
|---|---:|---:|---:|---|---|---|
| RMSE | 5.188306 | 2.438814 | +2.749492 | [1.924463, 3.556188] | [1.318396, 4.049834] | Favors candidate |
| MAE | 3.675240 | 1.567286 | +2.107954 | [1.553692, 2.716034] | [1.208356, 3.122296] | Favors candidate |
| Pearson | 0.574430 | 0.910495 | +0.336065 | [0.208591, 0.470738] | [0.139585, 0.562477] | Favors candidate |
| Spearman | 0.512308 | 0.906317 | +0.394009 | [0.241962, 0.536175] | [0.169184, 0.620743] | Favors candidate |
| R2 | 0.178512 | 0.818487 | +0.639975 | [0.402096, 0.946331] | [0.264569, 1.194256] | Favors candidate |

## HistGB four-arm study | ImageNet16-120 (partial) | target_ge20
A -> A_T

n=187; groups=41; Bonferroni40 within dataset

| Metric | Reference | Candidate | Improvement | Unadjusted 95% CI | Adjusted CI | Adjusted result |
|---|---:|---:|---:|---|---|---|
| RMSE | 5.188306 | 3.768336 | +1.419970 | [0.757758, 2.161296] | [0.302791, 2.707363] | Favors candidate |
| MAE | 3.675240 | 2.655124 | +1.020116 | [0.564315, 1.600938] | [0.330361, 2.057399] | Favors candidate |
| Pearson | 0.574430 | 0.764026 | +0.189596 | [0.087470, 0.305571] | [0.025451, 0.389553] | Favors candidate |
| Spearman | 0.512308 | 0.736617 | +0.224309 | [0.115875, 0.345771] | [0.061109, 0.440197] | Favors candidate |
| R2 | 0.178512 | 0.566640 | +0.388128 | [0.193523, 0.639419] | [0.070585, 0.832169] | Favors candidate |

## HistGB four-arm study | ImageNet16-120 (partial) | target_ge20
A_T -> A_LC_T

n=187; groups=41; Bonferroni40 within dataset

| Metric | Reference | Candidate | Improvement | Unadjusted 95% CI | Adjusted CI | Adjusted result |
|---|---:|---:|---:|---|---|---|
| RMSE | 3.768336 | 2.310350 | +1.457986 | [0.899496, 1.965375] | [0.545299, 2.290934] | Favors candidate |
| MAE | 2.655124 | 1.600975 | +1.054150 | [0.648861, 1.428594] | [0.440425, 1.646497] | Favors candidate |
| Pearson | 0.764026 | 0.919831 | +0.155806 | [0.088520, 0.222928] | [0.050871, 0.271707] | Favors candidate |
| Spearman | 0.736617 | 0.914640 | +0.178023 | [0.084931, 0.267273] | [0.052221, 0.326955] | Favors candidate |
| R2 | 0.566640 | 0.837106 | +0.270466 | [0.154953, 0.419914] | [0.090557, 0.520369] | Favors candidate |

## NB201 Qwen supporting metrics | CIFAR-10-valid | all
No layer -> Taylor

n=275; groups=46; Bonferroni12 across datasets

| Metric | Reference | Candidate | Improvement | Unadjusted 95% CI | Adjusted CI | Adjusted result |
|---|---:|---:|---:|---|---|---|
| RMSE | 4.949945 | 3.905624 | +1.044321 | [0.553996, 1.543371] | [0.341966, 1.766199] | Favors candidate |
| Pearson | 0.835534 | 0.899673 | +0.064139 | [0.027249, 0.214997] | [0.016380, 0.315408] | Favors candidate |
| Spearman | 0.494613 | 0.707213 | +0.212600 | [0.123369, 0.295406] | [0.083334, 0.335729] | Favors candidate |
| R2 | 0.670718 | 0.794273 | +0.123554 | [0.054014, 0.380641] | [0.032776, 0.602990] | Favors candidate |

## NB201 Qwen supporting metrics | CIFAR-100 | all
No layer -> Taylor

n=275; groups=46; Bonferroni12 across datasets

| Metric | Reference | Candidate | Improvement | Unadjusted 95% CI | Adjusted CI | Adjusted result |
|---|---:|---:|---:|---|---|---|
| RMSE | 5.943643 | 4.436380 | +1.507263 | [0.968002, 2.052534] | [0.730081, 2.277781] | Favors candidate |
| Pearson | 0.783911 | 0.882843 | +0.098933 | [0.047676, 0.202820] | [0.032863, 0.283441] | Favors candidate |
| Spearman | 0.584076 | 0.805912 | +0.221836 | [0.140022, 0.287700] | [0.102269, 0.320049] | Favors candidate |
| R2 | 0.590547 | 0.771904 | +0.181357 | [0.096396, 0.344555] | [0.069802, 0.448471] | Favors candidate |

## NB201 Qwen supporting metrics | ImageNet16-120 | all
No layer -> Taylor

n=275; groups=46; Bonferroni12 across datasets

| Metric | Reference | Candidate | Improvement | Unadjusted 95% CI | Adjusted CI | Adjusted result |
|---|---:|---:|---:|---|---|---|
| RMSE | 6.656276 | 4.727641 | +1.928635 | [1.212349, 2.667836] | [0.926523, 3.046091] | Favors candidate |
| Pearson | 0.642587 | 0.808895 | +0.166308 | [0.089349, 0.249953] | [0.060255, 0.294062] | Favors candidate |
| Spearman | 0.513119 | 0.698338 | +0.185219 | [0.099067, 0.258523] | [0.062109, 0.297465] | Favors candidate |
| R2 | 0.233715 | 0.612531 | +0.378816 | [0.216258, 0.622466] | [0.162342, 0.778571] | Favors candidate |

## LEMUR extra comparisons | LEMUR | all
All seven / ZCP-OFF -> Qwen+Taylor

n=115; groups=not grouped; Bonferroni20 across four contrasts

| Metric | Reference | Candidate | Improvement | Unadjusted 95% CI | Adjusted CI | Adjusted result |
|---|---:|---:|---:|---|---|---|
| RMSE | 10.160341 | 8.474932 | +1.685409 | [0.198236, 3.420741] | [-0.182882, 4.597154] | Inconclusive |
| MAE | 6.626679 | 5.898650 | +0.728029 | [0.125726, 1.470767] | [-0.111626, 2.009404] | Inconclusive |
| Pearson | 0.906766 | 0.940093 | +0.033328 | [0.006658, 0.073242] | [0.001537, 0.105168] | Favors candidate |
| Spearman | 0.779940 | 0.821770 | +0.041830 | [0.010209, 0.081709] | [-0.003857, 0.110911] | Inconclusive |
| R2 | 0.796730 | 0.859505 | +0.062775 | [0.006600, 0.145066] | [-0.005553, 0.204710] | Inconclusive |

## LEMUR extra comparisons | LEMUR | all
XGBoost / 3 accuracies -> Qwen+Taylor

n=115; groups=not grouped; Bonferroni20 across four contrasts

| Metric | Reference | Candidate | Improvement | Unadjusted 95% CI | Adjusted CI | Adjusted result |
|---|---:|---:|---:|---|---|---|
| RMSE | 8.759291 | 8.474932 | +0.284359 | [-1.086636, 1.878835] | [-1.675464, 2.961748] | Inconclusive |
| MAE | 6.137053 | 5.898650 | +0.238403 | [-0.497202, 1.035509] | [-0.871677, 1.579572] | Inconclusive |
| Pearson | 0.925838 | 0.940093 | +0.014255 | [-0.006961, 0.042109] | [-0.017863, 0.062457] | Inconclusive |
| Spearman | 0.808885 | 0.821770 | +0.012886 | [-0.026370, 0.050702] | [-0.053575, 0.074694] | Inconclusive |
| R2 | 0.850163 | 0.859505 | +0.009342 | [-0.038917, 0.064551] | [-0.065479, 0.101215] | Inconclusive |

## LEMUR extra comparisons | LEMUR | all
Calibrated SynFlow -> Qwen+Taylor

n=115; groups=not grouped; Bonferroni20 across four contrasts

| Metric | Reference | Candidate | Improvement | Unadjusted 95% CI | Adjusted CI | Adjusted result |
|---|---:|---:|---:|---|---|---|
| RMSE | 27.795138 | 8.474932 | +19.320206 | [15.860270, 22.769427] | [14.126515, 24.575167] | Favors candidate |
| MAE | 24.337385 | 5.898650 | +18.438735 | [15.653158, 21.297374] | [14.170867, 22.839924] | Favors candidate |
| Pearson | 0.051881 | 0.940093 | +0.888212 | [0.701977, 1.076403] | [0.600715, 1.176550] | Favors candidate |
| Spearman | 0.083790 | 0.821770 | +0.737980 | [0.525627, 0.944173] | [0.419950, 1.069987] | Favors candidate |
| R2 | -0.508617 | 0.859505 | +1.368121 | [1.110505, 1.776492] | [0.994813, 2.074096] | Favors candidate |

## LEMUR extra comparisons | LEMUR | all
Calibrated NASWOT -> Qwen+Taylor

n=115; groups=not grouped; Bonferroni20 across four contrasts

| Metric | Reference | Candidate | Improvement | Unadjusted 95% CI | Adjusted CI | Adjusted result |
|---|---:|---:|---:|---|---|---|
| RMSE | 24.453594 | 8.474932 | +15.978662 | [12.553150, 19.376639] | [10.611682, 21.151585] | Favors candidate |
| MAE | 20.723449 | 5.898650 | +14.824798 | [11.966925, 17.680546] | [10.408847, 19.304846] | Favors candidate |
| Pearson | 0.108310 | 0.940093 | +0.831783 | [0.647001, 1.022154] | [0.556891, 1.132748] | Favors candidate |
| Spearman | 0.084576 | 0.821770 | +0.737194 | [0.526072, 0.928088] | [0.426527, 1.047388] | Favors candidate |
| R2 | -0.167687 | 0.859505 | +1.027192 | [0.890723, 1.243717] | [0.820754, 1.391820] | Favors candidate |

## Qwen vs no-Taylor classical | LEMUR | all
ridge without Taylor -> Qwen+Taylor

n=115; groups=not grouped; Bonferroni15 across three contrasts

| Metric | Reference | Candidate | Improvement | Unadjusted 95% CI | Adjusted CI | Adjusted result |
|---|---:|---:|---:|---|---|---|
| RMSE | 9.649378 | 8.474932 | +1.174446 | [-1.023560, 3.570754] | [-1.903617, 4.841569] | Inconclusive |
| MAE | 7.205472 | 5.898650 | +1.306822 | [0.012624, 2.641214] | [-0.613308, 3.345807] | Inconclusive |
| Pearson | 0.916650 | 0.940093 | +0.023444 | [-0.010557, 0.070303] | [-0.023182, 0.097848] | Inconclusive |
| Spearman | 0.823698 | 0.821770 | -0.001928 | [-0.054056, 0.056806] | [-0.085601, 0.097039] | Inconclusive |
| R2 | 0.818181 | 0.859505 | +0.041324 | [-0.041854, 0.124296] | [-0.085245, 0.173168] | Inconclusive |

## Qwen vs no-Taylor classical | LEMUR | all
random_forest without Taylor -> Qwen+Taylor

n=115; groups=not grouped; Bonferroni15 across three contrasts

| Metric | Reference | Candidate | Improvement | Unadjusted 95% CI | Adjusted CI | Adjusted result |
|---|---:|---:|---:|---|---|---|
| RMSE | 10.089249 | 8.474932 | +1.614317 | [-0.644403, 3.934987] | [-1.708286, 5.029357] | Inconclusive |
| MAE | 7.587871 | 5.898650 | +1.689221 | [0.322297, 3.055110] | [-0.259081, 3.730413] | Inconclusive |
| Pearson | 0.907240 | 0.940093 | +0.032853 | [-0.001362, 0.078333] | [-0.015947, 0.108008] | Inconclusive |
| Spearman | 0.817502 | 0.821770 | +0.004268 | [-0.050183, 0.062262] | [-0.079368, 0.093401] | Inconclusive |
| R2 | 0.801141 | 0.859505 | +0.058364 | [-0.025936, 0.149228] | [-0.068314, 0.202111] | Inconclusive |

## Qwen vs no-Taylor classical | LEMUR | all
hist_gradient_boosting without Taylor -> Qwen+Taylor

n=115; groups=not grouped; Bonferroni15 across three contrasts

| Metric | Reference | Candidate | Improvement | Unadjusted 95% CI | Adjusted CI | Adjusted result |
|---|---:|---:|---:|---|---|---|
| RMSE | 9.653649 | 8.474932 | +1.178718 | [-0.590330, 3.095119] | [-1.302930, 4.008482] | Inconclusive |
| MAE | 7.258006 | 5.898650 | +1.359356 | [0.222325, 2.510767] | [-0.290811, 3.044126] | Inconclusive |
| Pearson | 0.910068 | 0.940093 | +0.030025 | [0.003366, 0.065504] | [-0.007211, 0.086552] | Inconclusive |
| Spearman | 0.841521 | 0.821770 | -0.019751 | [-0.071899, 0.028826] | [-0.104076, 0.051227] | Inconclusive |
| R2 | 0.818020 | 0.859505 | +0.041485 | [-0.023088, 0.110135] | [-0.057064, 0.146993] | Inconclusive |

