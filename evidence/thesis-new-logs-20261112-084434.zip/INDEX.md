# Additional thesis logs and numerical evidence

Compared against: `project_final_4_(1).zip`

This ZIP contains local evidence files absent from the supplied LaTeX project, including nested uploaded archives. It does not imply these results are missing from the written paper.

## Start here

- `recent_results/nested-outer-six-seed-analysis-v1/`: six-seed nested results and Bonferroni5 paired intervals.
- `recent_results/statistical-test-results-full-v1/`: consolidated recent 167-row report; not every historical thesis test.
- `recent_results/loss-confidence-all-metrics-v1/`: HistGB four-arm contrasts, both populations, Bonferroni40.
- `recent_results/nb201-qwen-extra-metrics-v1/`: non-MAE NB201 Qwen supporting intervals, Bonferroni12.
- `recent_results/lemur-extra-paired-intervals-v1/`: all-seven/XGBoost/SynFlow/NASWOT comparisons, Bonferroni20.
- `recent_results/classical-no-taylor-v1/`: new CPU classical fits, preserved Qwen reference, selection and completion evidence.
- `cluster_exports/`: original transferred prediction/receipt/registry evidence not already present in the project.
- `workspace_evidence/`, `workspace_experiment_logs/`, `workspace_logsv2/`: additional historical evidence, retaining experiment/version paths.

Some listed folders/files may be absent if all their contents already exist in the supplied LaTeX ZIP or duplicate another included file. `MANIFEST.json` records every match and alias.

## Important boundaries

- Delta evidence package, not a standalone reproduction environment. Original receipt files can reference members omitted because they are already in LaTeX; use this manifest to resolve them.
- No live Overleaf or cluster inspection. Only local sources and the supplied project export were compared.
- No new original training stdout has been invented. A .log file may be a metrics export or later analysis report.
- Point4 raw measurement CSVs and high-CV counts were verified by user-run cluster commands, but their CSV export is not present locally and is not reconstructed here.
- Historical and newer analyses retain separate paths/provenance; older resampling protocols must not replace the newer corrected analyses.

## Counts

Included evidence files: 410
Source entries already in LaTeX: 19452
Additional local duplicate sources: 152
Skipped empty/suspicious files: 0

Originals were not modified or deleted. No new experiments were run. All included files retain their original bytes.
